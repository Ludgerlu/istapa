<?php $__env->startSection('title', 'Record Payment'); ?>
<?php $__env->startSection('page-title', 'Record Payment'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('fees.index')); ?>" class="btn">← Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:560px">
<form method="POST" action="<?php echo e(route('fees.store-payment')); ?>">
    <?php echo csrf_field(); ?>

    <div class="card">
        <div class="card-title" style="margin-bottom:1rem">Payment details</div>

        <div class="form-group">
            <label>Student *</label>
            <select name="student_id" required>
                <option value="">— Select student —</option>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->id); ?>" <?php echo e(old('student_id') == $student->id ? 'selected' : ''); ?>>
                        <?php echo e($student->name); ?> — <?php echo e($student->schoolClass->name ?? ''); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['student_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-msg"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label>Amount (FCFA) *</label>
                <input type="number" name="amount" value="<?php echo e(old('amount')); ?>"
                       placeholder="e.g. 50000" min="1" required>
                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-msg"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label>Payment date *</label>
                <input type="date" name="paid_at" value="<?php echo e(old('paid_at', today()->format('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['paid_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-msg"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-grid">
            <div class="form-group">
                <label>Payment method *</label>
                <select name="method" required>
                    <option value="">— Select —</option>
                    <option value="cash"          <?php echo e(old('method') === 'cash'          ? 'selected' : ''); ?>>Cash</option>
                    <option value="mobile_money"  <?php echo e(old('method') === 'mobile_money'  ? 'selected' : ''); ?>>Mobile Money</option>
                    <option value="bank_transfer" <?php echo e(old('method') === 'bank_transfer' ? 'selected' : ''); ?>>Bank transfer</option>
                    <option value="cheque"        <?php echo e(old('method') === 'cheque'        ? 'selected' : ''); ?>>Cheque</option>
                </select>
                <?php $__errorArgs = ['method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-msg"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label>Receipt / reference no.</label>
                <input name="reference" value="<?php echo e(old('reference')); ?>" placeholder="e.g. REC-0042">
                <?php $__errorArgs = ['reference'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="error-msg"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group">
            <label>Notes (optional)</label>
            <input name="notes" value="<?php echo e(old('notes')); ?>" placeholder="e.g. First instalment">
        </div>
    </div>

    <div style="display:flex;gap:8px;justify-content:flex-end">
        <a href="<?php echo e(route('fees.index')); ?>" class="btn">Cancel</a>
        <button type="submit" class="btn btn-primary">Record payment</button>
    </div>
</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\fees\record-payment.blade.php ENDPATH**/ ?>