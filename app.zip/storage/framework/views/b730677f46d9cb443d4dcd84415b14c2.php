<?php $__env->startSection('title', 'Mark Attendance — ' . $class->name); ?>
<?php $__env->startSection('page-title', 'Mark Attendance'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('attendance.index')); ?>" class="btn">← Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card" style="margin-bottom:.75rem">
    <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap">
        <div>
            <div style="font-size:11px;color:#888780">Class</div>
            <div style="font-weight:500"><?php echo e($class->name); ?></div>
        </div>
        <div style="width:1px;height:32px;background:#E0DFD8"></div>
        <div>
            <div style="font-size:11px;color:#888780">Date</div>
            <div style="font-weight:500"><?php echo e($date->format('d F Y')); ?></div>
        </div>
        <div style="width:1px;height:32px;background:#E0DFD8"></div>
        <div>
            <div style="font-size:11px;color:#888780">Students</div>
            <div style="font-weight:500"><?php echo e($students->count()); ?></div>
        </div>
        <div style="margin-left:auto;display:flex;gap:8px">
            <button type="button" class="btn btn-sm" onclick="markAll('present')">All present</button>
            <button type="button" class="btn btn-sm" onclick="markAll('absent')">All absent</button>
        </div>
    </div>
</div>

<form method="POST" action="<?php echo e(route('attendance.store')); ?>">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="class_id" value="<?php echo e($class->id); ?>">
    <input type="hidden" name="date" value="<?php echo e($date->toDateString()); ?>">

    <div class="card">
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th style="width:40%">Student</th>
                        <th style="width:15%;text-align:center">
                            <span style="color:#3B6D11">✓ Present</span>
                        </th>
                        <th style="width:15%;text-align:center">
                            <span style="color:#A32D2D">✕ Absent</span>
                        </th>
                        <th style="width:15%;text-align:center">
                            <span style="color:#854F0B">⏱ Late</span>
                        </th>
                        <th>Note</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $current = $existing[$student->id] ?? 'present'; ?>
                        <tr>
                            <td>
                                <div style="display:flex;align-items:center">
                                    <div class="avatar" style="background:#E6F1FB;color:#185FA5">
                                        <?php echo e(strtoupper(substr($student->name, 0, 2))); ?>

                                    </div>
                                    <?php echo e($student->name); ?>

                                </div>
                            </td>
                            <td style="text-align:center">
                                <input type="radio"
                                       name="attendance[<?php echo e($student->id); ?>][status]"
                                       value="present"
                                       <?php echo e($current === 'present' ? 'checked' : ''); ?>>
                            </td>
                            <td style="text-align:center">
                                <input type="radio"
                                       name="attendance[<?php echo e($student->id); ?>][status]"
                                       value="absent"
                                       <?php echo e($current === 'absent' ? 'checked' : ''); ?>>
                            </td>
                            <td style="text-align:center">
                                <input type="radio"
                                       name="attendance[<?php echo e($student->id); ?>][status]"
                                       value="late"
                                       <?php echo e($current === 'late' ? 'checked' : ''); ?>>
                            </td>
                            <td>
                                <input type="text"
                                       name="attendance[<?php echo e($student->id); ?>][note]"
                                       placeholder="optional note…"
                                       style="padding:4px 8px;font-size:12px">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <div style="display:flex;justify-content:flex-end;gap:8px">
        <a href="<?php echo e(route('attendance.index')); ?>" class="btn">Cancel</a>
        <button type="submit" class="btn btn-primary">Save attendance</button>
    </div>
</form>

<script>
function markAll(status) {
    document.querySelectorAll(`input[type="radio"][value="${status}"]`).forEach(r => r.checked = true);
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\attendances\mark.blade.php ENDPATH**/ ?>