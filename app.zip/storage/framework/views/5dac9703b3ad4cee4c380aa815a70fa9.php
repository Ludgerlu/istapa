

<?php $__env->startSection('title', 'Classes'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Classes</h4>
    <a href="<?php echo e(route('admin.classes.create')); ?>" class="btn btn-main rounded-pill"><i class="ph ph-plus-circle"></i> Nouvelle classe</a>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-3">
            <label>Rechercher</label>
            <input type="text" name="q" class="form-control" placeholder="Nom, section..." value="<?php echo e(request('q')); ?>">
        </div>
        <div class="col-md-3">
            <label>Programme</label>
            <select name="program_id" class="form-select">
                <option value="">Tous</option>
                <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php echo e(request('program_id')==$p->id ? 'selected' : ''); ?>><?php echo e($p->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label>Année scolaire</label>
            <select name="academic_year_id" class="form-select">
                <option value="">Toutes</option>
                <?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($y->id); ?>" <?php echo e(request('academic_year_id')==$y->id ? 'selected' : ''); ?>><?php echo e($y->label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-main w-100">Filtrer</button>
        </div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <div class="overflow-x-auto">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr>
                    <th>Nom</th>
                    <th>Section</th>
                    <th>Programme</th>
                    <th>Année scolaire</th>
                    <th>Capacité</th>
                    <th>Professeur principal</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($class->name); ?></td>
                    <td><?php echo e($class->section ?? '—'); ?></td>
                    <td><?php echo e($class->program->name ?? '—'); ?></td>
                    <td><?php echo e($class->academicYear->label ?? '—'); ?></td>
                    <td><?php echo e($class->capacity ?? '∞'); ?></td>
                    <td><?php echo e($class->headTeacher->user->full_name ?? '—'); ?></td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.classes.show', $class)); ?>" class="btn btn-sm bg-main-600"><i class="ph ph-eye"></i></a>
                        <a href="<?php echo e(route('admin.classes.edit', $class)); ?>" class="btn btn-sm bg-main-600"><i class="ph ph-pencil"></i></a>
                        <form action="<?php echo e(route('admin.classes.destroy', $class)); ?>" method="POST" onsubmit="return confirm('Supprimer cette classe ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm bg-danger-600"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-40">Aucune classe trouvée. <a href="<?php echo e(route('admin.classes.create')); ?>">Créer la première</a></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-24 d-flex justify-content-end">
        <?php echo e($classes->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\classes\index.blade.php ENDPATH**/ ?>