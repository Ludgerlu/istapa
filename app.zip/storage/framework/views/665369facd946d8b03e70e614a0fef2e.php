

<?php $__env->startSection('title', 'Créer un article'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Nouvel article</h4>
</div>

<form action="<?php echo e(route('admin.blogs.store')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>

    <div class="bg-white rounded-10 p-24 mb-24">
        <div class="row g-4">
            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Catégorie</label>
                <select name="blog_category_id" class="form-select">
                    <option value="">-- Aucune --</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>" <?php echo e(old('blog_category_id') == $cat->id ? 'selected' : ''); ?>>
                            <?php echo e($cat->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Statut</label>
                <select name="status" class="form-select" required>
                    <option value="draft" <?php echo e(old('status') == 'draft' ? 'selected' : ''); ?>>Brouillon</option>
                    <option value="published" <?php echo e(old('status') == 'published' ? 'selected' : ''); ?>>Publié</option>
                    <option value="archived" <?php echo e(old('status') == 'archived' ? 'selected' : ''); ?>>Archivé</option>
                </select>
            </div>

            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Date de publication</label>
                <input type="datetime-local" name="published_at" class="form-control" value="<?php echo e(old('published_at')); ?>">
            </div>

            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Image de couverture</label>
                <input type="file" name="cover_image" class="form-control" accept="image/*">
            </div>

            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Titre (EN) <span class="text-danger">*</span></label>
                <input type="text" name="title_en" class="form-control" value="<?php echo e(old('title_en')); ?>" required>
            </div>
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Titre (FR) <span class="text-danger">*</span></label>
                <input type="text" name="title_fr" class="form-control" value="<?php echo e(old('title_fr')); ?>" required>
            </div>

            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Extrait (EN)</label>
                <textarea name="excerpt_en" rows="2" class="form-control"><?php echo e(old('excerpt_en')); ?></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Extrait (FR)</label>
                <textarea name="excerpt_fr" rows="2" class="form-control"><?php echo e(old('excerpt_fr')); ?></textarea>
            </div>

            
            <div class="col-md-12">
                <label class="form-label text-14 fw-medium">Contenu (EN) <span class="text-danger">*</span></label>
                <textarea name="content_en" rows="10" class="form-control" required><?php echo e(old('content_en')); ?></textarea>
            </div>
            <div class="col-md-12">
                <label class="form-label text-14 fw-medium">Contenu (FR) <span class="text-danger">*</span></label>
                <textarea name="content_fr" rows="10" class="form-control" required><?php echo e(old('content_fr')); ?></textarea>
            </div>

            
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Meta description (EN)</label>
                <textarea name="meta_description_en" rows="2" class="form-control"><?php echo e(old('meta_description_en')); ?></textarea>
            </div>
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Meta description (FR)</label>
                <textarea name="meta_description_fr" rows="2" class="form-control"><?php echo e(old('meta_description_fr')); ?></textarea>
            </div>
        </div>
    </div>

    <div class="d-flex gap-12 justify-content-end">
        <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-outline-secondary rounded-pill px-24">Annuler</a>
        <button type="submit" class="btn bg-main-600 text-white rounded-pill px-24">Enregistrer</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\blog\create.blade.php ENDPATH**/ ?>