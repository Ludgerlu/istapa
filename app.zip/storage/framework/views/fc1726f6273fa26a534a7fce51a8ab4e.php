

<?php $__env->startSection('title', 'Albums photo'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Albums photo</h4>
    <a href="<?php echo e(route('admin.gallery.create')); ?>" class="btn btn-main rounded-pill"><i class="ph ph-plus-circle"></i> Nouvel album</a>
</div>

<div class="bg-white rounded-10 p-24">
    <?php if($albums->count()): ?>
    <div class="row g-4">
        <?php $__currentLoopData = $albums; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $album): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-lg-3">
            <div class="card h-100 border-0 shadow-sm rounded-10 overflow-hidden">
                <?php if($album->cover_image): ?>
                <img src="<?php echo e(asset('storage/'.$album->cover_image)); ?>" class="card-img-top" style="height: 180px; object-fit: cover;">
                <?php else: ?>
                <div class="bg-main-25 d-flex align-items-center justify-content-center" style="height: 180px;">
                    <i class="ph ph-image text-main-600 text-40"></i>
                </div>
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($album->title); ?></h5>
                    <p class="card-text text-muted small"><?php echo e(Str::limit($album->description, 60)); ?></p>
                    <p class="mb-2"><i class="ph ph-image"></i> <?php echo e($album->images->count()); ?> image(s)</p>
                </div>
                <div class="card-footer bg-transparent border-0 d-flex gap-8 pb-16">
                    <a href="<?php echo e(route('admin.gallery.show', $album)); ?>" class="btn btn-sm bg-main-600 text-white rounded-pill"><i class="ph ph-eye"></i> Voir</a>
                    <a href="<?php echo e(route('admin.gallery.edit', $album)); ?>" class="btn btn-sm bg-warning-600 text-white rounded-pill"><i class="ph ph-pencil"></i> Éditer</a>
                    <form action="<?php echo e(route('admin.gallery.destroy', $album)); ?>" method="POST" onsubmit="return confirm('Supprimer cet album ?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm bg-danger-600 text-white rounded-circle"><i class="ph ph-trash"></i></button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="mt-24 d-flex justify-content-end">
        <?php echo e($albums->links()); ?>

    </div>
    <?php else: ?>
    <div class="text-center py-40">
        <i class="ph ph-images text-60 text-muted mb-16"></i>
        <p class="text-muted">Aucun album. <a href="<?php echo e(route('admin.gallery.create')); ?>">Créez le premier album</a></p>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istapa/public_html/resources/views/admin/gallery/index.blade.php ENDPATH**/ ?>