
<?php $__env->startSection('title', 'Créer un frais'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Ajouter des frais</h4></div>
<form action="<?php echo e(route('admin.fees.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-3">
            <div class="col-md-4"><label>Classe *</label><select name="class_id" class="form-select" required><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Année scolaire *</label><select name="academic_year_id" class="form-select" required><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($y->id); ?>"><?php echo e($y->label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Catégorie *</label><select name="fee_category_id" class="form-select" required><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Montant (FCFA) *</label><input type="number" step="0.01" name="amount" class="form-control" required></div>
            <div class="col-md-4"><label>Date d'échéance</label><input type="date" name="due_date" class="form-control"></div>
            <div class="col-md-12"><label>Description</label><textarea name="description" class="form-control" rows="3"></textarea></div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24"><a href="<?php echo e(route('admin.fees.index')); ?>" class="btn bg-warning-100 text-warning-700">Annuler</a><button type="submit" class="btn btn-main">Enregistrer</button></div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\fees\create.blade.php ENDPATH**/ ?>