

<?php $__env->startSection('title', 'Modifier l\'année académique'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Modifier : <?php echo e($academicYear->label); ?></h4>
</div>

<form action="<?php echo e(route('admin.academic-years.update', $academicYear)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-4">
            <div class="col-md-12">
                <label class="form-label text-14 fw-medium">Libellé <span class="text-danger">*</span></label>
                <input type="text" name="label" class="form-control" value="<?php echo e(old('label', $academicYear->label)); ?>" required>
                <?php $__errorArgs = ['label'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Date début <span class="text-danger">*</span></label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(old('start_date', $academicYear->start_date->format('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6">
                <label class="form-label text-14 fw-medium">Date fin <span class="text-danger">*</span></label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', $academicYear->end_date->format('Y-m-d'))); ?>" required>
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-12">
                <div class="form-check">
                    <input type="checkbox" name="is_current" value="1" class="form-check-input" id="is_current" <?php echo e(old('is_current', $academicYear->is_current) ? 'checked' : ''); ?>>
                    <label class="form-check-label text-14" for="is_current">Définir comme année en cours</label>
                    <small class="d-block text-muted">Si coché, toute autre année actuelle sera désactivée.</small>
                </div>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24">
        <a href="<?php echo e(route('admin.academic-years.index')); ?>" class="btn btn-outline-secondary rounded-pill px-24">Annuler</a>
        <button type="submit" class="btn btn-main rounded-pill px-24">Mettre à jour</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\academic-years\edit.blade.php ENDPATH**/ ?>