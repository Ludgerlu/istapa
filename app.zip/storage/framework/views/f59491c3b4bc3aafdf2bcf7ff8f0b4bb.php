
<?php $__env->startSection('title', 'Créer une matière'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Nouvelle matière</h4></div>
<form action="<?php echo e(route('admin.subjects.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-3">
            <div class="col-md-6">
                <label>Nom *</label>
                <input type="text" name="name" class="form-control" required value="<?php echo e(old('name')); ?>">
            </div>
            <div class="col-md-6">
                <label>Code</label>
                <input type="text" name="code" class="form-control" value="<?php echo e(old('code')); ?>">
                <small class="text-muted">Ex: MATH101, PHY202</small>
            </div>
            <div class="col-md-4">
                <label>Classe *</label>
                <select name="class_id" class="form-select" required>
                    <option value="">-- Sélectionner --</option>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>" <?php echo e(old(('class_id')==$c->id || $classId==$c->id )? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Enseignant</label>
                <select name="teacher_id" class="form-select">
                    <option value="">-- Aucun --</option>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($t->user_id); ?>" <?php echo e(old('teacher_id')==$t->user_id ? 'selected' : ''); ?>><?php echo e($t->user->first_name); ?> <?php echo e($t->user->last_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Coefficient</label>
                <input type="number" step="0.5" name="coefficient" class="form-control" value="<?php echo e(old('coefficient', 1)); ?>">
            </div>
            <div class="col-md-2">
                <label>Heures/semaine</label>
                <input type="number" step="0.5" name="hours_per_week" class="form-control" value="<?php echo e(old('hours_per_week')); ?>">
            </div>
            <div class="col-md-12">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24">
        <a href="<?php echo e(route('admin.subjects.index')); ?>" class="btn bg-danger-600 rounded-pill">Annuler</a>
        <button type="submit" class="btn btn-main rounded-pill">Créer</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\subjects\create.blade.php ENDPATH**/ ?>