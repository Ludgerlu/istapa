

<?php $__env->startSection('title', $event->title); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-24 flex-wrap gap-12">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0"><?php echo e($event->title); ?></h4>
    <div class="d-flex gap-8">
        <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="btn bg-main-600 text-white rounded-pill px-20">
            <i class="ph ph-pencil"></i> Modifier
        </a>
        <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST" onsubmit="return confirm('Supprimer définitivement cet événement ?')">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn bg-warning-100 text-warning-600 rounded-pill px-20">
                <i class="ph ph-trash"></i> Supprimer
            </button>
        </form>
    </div>
</div>


<div class="bg-white rounded-10 p-24 mb-32">
    <div class="row">
        <?php if($event->cover_image): ?>
        <div class="col-md-4 mb-3 mb-md-0">
            <img src="<?php echo e(asset('storage/' . $event->cover_image)); ?>" class="img-fluid rounded-10" alt="Cover">
        </div>
        <div class="col-md-8">
        <?php else: ?>
        <div class="col-12">
        <?php endif; ?>
            <div class="d-flex flex-wrap gap-16 align-items-center mb-16">
                <span class="badge <?php echo e($event->is_published ? 'bg-success-100 text-success-600' : 'bg-neutral-100 text-neutral-500'); ?>">
                    <?php echo e($event->is_published ? 'Publié' : 'Brouillon'); ?>

                </span>
                <span class="text-13 text-neutral-400">
                    <i class="ph ph-calendar"></i> 
                    <?php echo e($event->start_date->format('d/m/Y')); ?>

                    <?php if($event->start_time): ?> à <?php echo e($event->start_time); ?> <?php endif; ?>
                    <?php if($event->end_date): ?>
                        → <?php echo e($event->end_date->format('d/m/Y')); ?>

                        <?php if($event->end_time): ?> à <?php echo e($event->end_time); ?> <?php endif; ?>
                    <?php endif; ?>
                </span>
                <?php if($event->location): ?>
                <span class="text-13 text-neutral-400">
                    <i class="ph ph-map-pin"></i> <?php echo e($event->location); ?>

                </span>
                <?php endif; ?>
            </div>
            <div class="content text-neutral-600 mb-16">
                <strong>Brève description :</strong>
                <p><?php echo e($event->short_description_en); ?></p>
                <strong>Contenu :</strong>
                <div><?php echo nl2br(e($event->content_en)); ?></div>
            </div>
            <div class="content text-neutral-600 mb-16">
                <strong>Brève description :</strong>
                <p><?php echo e($event->short_description_fr); ?></p>
                <strong>Contenu :</strong>
                <div><?php echo nl2br(e($event->content_fr)); ?></div>
            </div>
            <?php if($event->video_url): ?>
            <div class="mt-16">
                <strong>Vidéo :</strong>
                <a href="<?php echo e($event->video_url); ?>" target="_blank" class="text-main-600"><?php echo e($event->video_url); ?></a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="bg-white rounded-10 p-24">
    <div class="d-flex align-items-center justify-content-between mb-20 flex-wrap gap-12">
        <h5 class="fw-semibold text-16 mb-0">Galerie d'images</h5>
        <span class="text-12 text-neutral-400"><?php echo e($event->images->count()); ?> image(s)</span>
    </div>

    
    <form action="<?php echo e(route('admin.events.storeImage', $event)); ?>" method="POST" enctype="multipart/form-data" class="mb-30">
        <?php echo csrf_field(); ?>
        <div class="row g-3 align-items-end">
            <div class="col-md-6">
                <label class="form-label text-14">Image</label>
                <input type="file" name="image" class="form-control" accept="image/*" required>
            </div>
            <div class="col-md-4">
                <label class="form-label text-14">Légende (optionnelle)</label>
                <input type="text" name="caption" class="form-control" placeholder="Description de l'image">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn bg-main-600 text-white w-100 rounded-pill">
                    <i class="ph ph-plus-circle"></i> Ajouter
                </button>
            </div>
        </div>
    </form>

    
    <?php if($event->images->count()): ?>
    <div class="sortable-images" data-reorder-url="<?php echo e(route('admin.events.reorderImages')); ?>">
        <div class="row g-3">
            <?php $__currentLoopData = $event->images->sortBy('sort_order'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 gallery-item" data-id="<?php echo e($image->id); ?>">
                <div class="card h-100 shadow-sm border-0 rounded-10 overflow-hidden">
                    <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" class="card-img-top" style="height: 160px; object-fit: cover;">
                    <div class="card-body p-12">
                        <p class="small text-muted mb-8"><?php echo e($image->caption ?: 'Sans légende'); ?></p>
                        <form action="<?php echo e(route('admin.events.destroyImage', $image)); ?>" method="POST" onsubmit="return confirm('Supprimer cette image ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm bg-warning-100 text-warning-600 w-100 rounded-pill">
                                <i class="ph ph-trash"></i> Supprimer
                            </button>
                        </form>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <p class="mt-3 text-muted small"><i class="ph ph-drag"></i> Glissez-déposez les images pour les réorganiser</p>
    <?php else: ?>
    <div class="alert alert-light text-center py-40">
        <i class="ph ph-image text-40 text-muted d-block mb-8"></i>
        Aucune image dans la galerie. Ajoutez-en via le formulaire ci-dessus.
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const container = document.querySelector('.sortable-images .row');
        if (container) {
            new Sortable(container, {
                animation: 150,
                handle: '.gallery-item',
                onEnd: function() {
                    let order = [];
                    document.querySelectorAll('.gallery-item').forEach((item, idx) => {
                        order.push(item.dataset.id);
                    });
                    const reorderUrl = container.closest('.sortable-images').dataset.reorderUrl;
                    fetch(reorderUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
                        },
                        body: JSON.stringify({ order: order })
                    });
                }
            });
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\events\show.blade.php ENDPATH**/ ?>