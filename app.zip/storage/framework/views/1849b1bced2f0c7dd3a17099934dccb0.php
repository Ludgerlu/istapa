

<?php $__env->startSection('title', 'Message de ' . $message->full_name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Détail du message</h4>
    <div>
        <a href="<?php echo e(route('admin.contact-messages.index')); ?>" class="btn bg-success-600 rounded-pill">
            <i class="ph ph-arrow-left"></i> Retour
        </a>
    </div>
</div>

<div class="bg-white rounded-10 p-24 mb-24">
    <div class="row mb-20">
        <div class="col-md-6">
            <p><strong>De :</strong> <?php echo e($message->full_name); ?></p>
            <p><strong>Email :</strong> <?php echo e($message->email); ?></p>
            <p><strong>Téléphone :</strong> <?php echo e($message->phone ?? '—'); ?></p>
        </div>
        <div class="col-md-6">
            <p><strong>Reçu le :</strong> <?php echo e($message->created_at); ?></p>
            <p><strong>IP :</strong> <?php echo e($message->ip_address ?? '—'); ?></p>
            <p><strong>Statut :</strong> 
                <?php if($message->status == 'new'): ?>
                    <span class="badge bg-warning-600">Non lu</span>
                <?php elseif($message->status == 'read'): ?>
                    <span class="badge bg-success-600">Lu</span>
                <?php else: ?>
                    <span class="badge bg-neutral-400">Archivé</span>
                <?php endif; ?>
            </p>
        </div>
    </div>
    <hr>
    <div class="mt-16">
        <h6><strong>Sujet :</strong> <?php echo e($message->subject); ?></h6>
        <div class="mt-16 p-16 bg-main-25 rounded-10">
            <p class="mb-0"><?php echo e(nl2br(e($message->message))); ?></p>
        </div>
    </div>
</div>

<div class="d-flex gap-12 justify-content-end">
    <?php if($message->status == 'new'): ?>
        <form action="<?php echo e(route('admin.contact-messages.mark-read', $message)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <button class="btn bg-success-600 rounded-pill px-24"><i class="ph ph-check"></i> Marquer comme lu</button>
        </form>
    <?php else: ?>
        <form action="<?php echo e(route('admin.contact-messages.mark-unread', $message)); ?>" method="POST">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <button class="btn bg-warning-600 rounded-pill px-24"><i class="ph ph-envelope"></i> Marquer non lu</button>
        </form>
    <?php endif; ?>
    <form action="<?php echo e(route('admin.contact-messages.destroy', $message)); ?>" method="POST" onsubmit="return confirm('Supprimer ce message ?')">
        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        <button class="btn bg-danger-600 rounded-pill px-24"><i class="ph ph-trash"></i> Supprimer</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\contact-messages\show.blade.php ENDPATH**/ ?>