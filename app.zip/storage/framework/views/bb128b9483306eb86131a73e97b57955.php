<?php use App\Models\BlogComment; ?>

<div class="comment-item mb-20 <?php if($depth > 0): ?> comment-reply <?php endif; ?>" id="comment-<?php echo e($comment->id); ?>">
    <div class="d-flex justify-content-between align-items-start">
        <div class="d-flex gap-12 flex-wrap align-items-start">
            <div class="bg-main-25 rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                <i class="ph ph-user text-main-600 text-20"></i>
            </div>
            <div>
                <div class="d-flex align-items-center gap-8 flex-wrap mb-4">
                    <strong class="text-14"><?php echo e($comment->user->name ?? 'Anonyme'); ?></strong>
                    <span class="text-12 text-neutral-400"><?php echo e($comment->created_at->format('d/m/Y H:i')); ?></span>
                    <?php if($comment->is_approved): ?>
                        <span class="badge bg-success-100 text-success-600 px-8 py-4 rounded-pill text-12">Approuvé</span>
                    <?php else: ?>
                        <span class="badge bg-warning-100 text-warning-600 px-8 py-4 rounded-pill text-12">En attente</span>
                    <?php endif; ?>
                </div>
                <div class="text-14 text-neutral-600 mb-8"><?php echo e(nl2br(e($comment->content))); ?></div>
                <div class="d-flex gap-12">
                    <?php if(!$comment->is_approved): ?>
                        <form action="<?php echo e(route('admin.comments.approve', $comment)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn bg-main-600 rounded-pill px-12 py-4 text-12">✅ Approuver</button>
                        </form>
                    <?php else: ?>
                        <form action="<?php echo e(route('admin.comments.disapprove', $comment)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn bg-warning-600 rounded-pill px-12 py-4 text-12">⛔ Désapprouver</button>
                        </form>
                    <?php endif; ?>
                    <form action="<?php echo e(route('admin.comments.destroy', $comment)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Supprimer ce commentaire ? Ses réponses aussi.')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn bg-danger-600 rounded-pill px-12 py-4 text-12">🗑️ Supprimer</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    
    <?php if($comment->replies && $comment->replies->count()): ?>
        <div class="replies-list mt-16">
            <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('admin.blog.partials.comment-item', ['comment' => $reply, 'depth' => $depth + 1], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div><?php /**PATH D:\pros\istapa\resources\views\admin\blog\partials\comment-item.blade.php ENDPATH**/ ?>