

<?php $__env->startSection('title', $class->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0"><?php echo e($class->name); ?> <?php if($class->section): ?> (<?php echo e($class->section); ?>) <?php endif; ?></h4>
    <div>
        <a href="<?php echo e(route('admin.classes.index')); ?>" class="btn bg-danger-600 rounded-pill">Retour</a>
        <a href="<?php echo e(route('admin.classes.edit', $class)); ?>" class="btn btn-main rounded-pill"><i class="ph ph-pencil"></i> Modifier</a>
    </div>
</div>


<div class="bg-white rounded-10 p-24 mb-24">
    <div class="row">
        <div class="col-md-3"><strong>Programme :</strong><br><?php echo e($class->program->name ?? '—'); ?></div>
        <div class="col-md-3"><strong>Année scolaire :</strong><br><?php echo e($class->academicYear->label ?? '—'); ?></div>
        <div class="col-md-3"><strong>Capacité :</strong><br><?php echo e($class->capacity ?? 'Illimitée'); ?></div>
        <div class="col-md-3"><strong>Professeur principal :</strong><br><?php echo e($class->headTeacher->user->full_name ?? 'Non assigné'); ?></div>
    </div>
</div>


<ul class="nav nav-tabs mb-24" id="classTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" data-bs-toggle="tab" data-bs-target="#subjects" type="button">Matières</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#exams" type="button">Examens</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#students" type="button">Élèves</button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" data-bs-toggle="tab" data-bs-target="#attendances" type="button">Présences</button>
    </li>
</ul>

<div class="tab-content">
    
    <div class="tab-pane fade show active" id="subjects">
        <div class="bg-white rounded-10 p-24">
            <div class="d-flex justify-content-between mb-16">
                <h5>Matières enseignées (<?php echo e($subjects->count()); ?>)</h5>
                <a href="<?php echo e(route('admin.subjects.create', ['class_id' => $class->id])); ?>" class="btn btn-sm btn-outline-main rounded-pill"><i class="ph ph-plus"></i> Ajouter</a>
            </div>
            <?php if($subjects->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-main-25">
                        <tr><th>Code</th><th>Nom</th><th>Coefficient</th><th>Heures/semaine</th><th>Enseignant</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($subject->code ?? '—'); ?></td>
                            <td><?php echo e($subject->name); ?></td>
                            <td><?php echo e($subject->coefficient); ?></td>
                            <td><?php echo e($subject->hours_per_week ?? '—'); ?></td>
                            <td><?php echo e($subject->teacher->user->full_name ?? 'Non assigné'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted">Aucune matière associée.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="tab-pane fade" id="exams">
        <div class="bg-white rounded-10 p-24">
            <h5>Examens planifiés (<?php echo e($exams->count()); ?>)</h5>
            <?php if($exams->count()): ?>
            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-20 border">
                <div class="card-header bg-main-25">
                    <strong><?php echo e($exam->name); ?></strong> (<?php echo e(ucfirst($exam->exam_type)); ?> – <?php echo e(ucfirst($exam->term)); ?>)<br>
                    <small>Du <?php echo e($exam->start_date ? $exam->start_date->format('d/m/Y') : '—'); ?> au <?php echo e($exam->end_date ? $exam->end_date->format('d/m/Y') : '—'); ?></small>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr><th>Matière</th><th>Date</th><th>Horaire</th><th>Total</th><th>Notes saisies</th></tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $exam->examSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $marksCount = $examSubject->marks->count(); ?>
                                <tr>
                                    <td><?php echo e($examSubject->subject->name ?? '—'); ?></td>
                                    <td><?php echo e($examSubject->exam_date ? $examSubject->exam_date->format('d/m/Y') : '—'); ?></td>
                                    <td><?php echo e($examSubject->start_time ? \Carbon\Carbon::parse($examSubject->start_time)->format('H:i') : '—'); ?> - <?php echo e($examSubject->end_time ? \Carbon\Carbon::parse($examSubject->end_time)->format('H:i') : '—'); ?></td>
                                    <td><?php echo e($examSubject->total_mark ?? '—'); ?></td>
                                    <td>
                                        <?php if($marksCount > 0): ?>
                                            <span class="badge bg-success-600"><?php echo e($marksCount); ?> notes</span>
                                        <?php else: ?>
                                            <span class="badge bg-neutral-400">Aucune</span>
                                        <?php endif; ?>
                                     </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <p class="text-muted">Aucun examen planifié.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="tab-pane fade" id="students">
        <div class="bg-white rounded-10 p-24">
            <h5>Élèves inscrits (<?php echo e($students->count()); ?>)</h5>
            <?php if($students->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-main-25">
                        <tr><th>Matricule</th><th>Nom complet</th><th>Email</th><th>Téléphone</th><th>Date inscription</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $student = $enrollment->student; ?>
                        <tr>
                            <td><?php echo e($student->matricule ?? '—'); ?></td>
                            <td><?php echo e($student->user->first_name ?? ''); ?> <?php echo e($student->user->last_name ?? ''); ?></td>
                            <td><?php echo e($student->user->email ?? '—'); ?></td>
                            <td><?php echo e($student->user->phone ?? '—'); ?></td>
                            <td><?php echo e($enrollment->enrollment_date ? \Carbon\Carbon::parse($enrollment->enrollment_date)->format('d/m/Y') : '—'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted">Aucun élève inscrit.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="tab-pane fade" id="attendances">
        <div class="bg-white rounded-10 p-24">
            <h5>Dernières sessions de présence</h5>
            <?php if($attendanceSessions->count()): ?>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead class="bg-main-25">
                        <tr><th>Date</th><th>Matière</th><th>Horaire</th><th>Enseignant</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $attendanceSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($session->session_date->format('d/m/Y')); ?></td>
                            <td><?php echo e($session->subject->name ?? '—'); ?></td>
                            <td><?php echo e($session->start_time ? \Carbon\Carbon::parse($session->start_time)->format('H:i') : '—'); ?> - <?php echo e($session->end_time ? \Carbon\Carbon::parse($session->end_time)->format('H:i') : '—'); ?></td>
                            <td><?php echo e($session->takenBy->full_name ?? '—'); ?></td>
                            <td><a href="<?php echo e(route('admin.attendances.show', $session)); ?>" class="btn btn-sm btn-outline-secondary"><i class="ph ph-eye"></i> Détails</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-20 d-flex justify-content-end">
                <?php echo e($attendanceSessions->links()); ?>

            </div>
            <?php else: ?>
            <p class="text-muted">Aucune session de présence enregistrée.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\classes\show.blade.php ENDPATH**/ ?>