

<?php $__env->startSection('title', 'Matières'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Matières</h4>
    <a href="#" class="btn btn-main rounded-pill"><i class="ph ph-plus-circle"></i> Nouvelle matière</a>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-3">
            <label>Rechercher</label>
            <input type="text" name="q" class="form-control" placeholder="Nom, code..." value="<?php echo e(request('q')); ?>">
        </div>
        <div class="col-md-3">
            <label>Classe</label>
            <select name="class_id" class="form-select">
                <option value="">Toutes</option>
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($c->id); ?>" <?php echo e(request('class_id')==$c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3">
            <label>Enseignant</label>
            <select name="teacher_id" class="form-select">
                <option value="">Tous</option>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($t->user_id); ?>" <?php echo e(request('teacher_id')==$t->user_id ? 'selected' : ''); ?>><?php echo e($t->user->first_name); ?> <?php echo e($t->user->last_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-md-3 d-flex align-items-end">
            <button type="submit" class="btn btn-main w-100">Filtrer</button>
        </div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <div class="overflow-x-auto">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr>
                    <th>Code</th>
                    <th>Nom</th>
                    <th>Classe</th>
                    <th>Enseignant</th>
                    <th>Coefficient</th>
                    <th>Heures/semaine</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($subject->code ?? '—'); ?></td>
                    <td><?php echo e($subject->name); ?></td>
                    <td><?php echo e($subject->class->name ?? '—'); ?></td>
                    <td><?php echo e($subject->teacher->user->full_name ?? 'Non assigné'); ?></td>
                    <td><?php echo e($subject->coefficient ?? '—'); ?></td>
                    <td><?php echo e($subject->hours_per_week ?? '—'); ?></td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.subjects.show', $subject)); ?>" class="btn btn-sm bg-main-600"><i class="ph ph-eye"></i></a>
                        <a href="<?php echo e(route('admin.subjects.edit', $subject)); ?>" class="btn btn-sm bg-warning-600"><i class="ph ph-pencil"></i></a>
                        <form action="<?php echo e(route('admin.subjects.destroy', $subject)); ?>" method="POST" onsubmit="return confirm('Supprimer cette matière ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm bg-danger-600"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-40">Aucune matière trouvée. <a href="<?php echo e(route('admin.subjects.create')); ?>">Créer la première</a></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-24 d-flex justify-content-end">
        <?php echo e($subjects->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\subjects\index.blade.php ENDPATH**/ ?>