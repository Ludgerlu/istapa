

<?php $__env->startSection('title', 'Modifier l\'examen'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Modifier l'examen</h4>
</div>

<form action="<?php echo e(route('admin.exams.update', $exam)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="bg-white rounded-10 p-24 mb-24">
        <div class="row g-3">
            
            <div class="col-md-12">
                <label class="form-label text-14 fw-medium">Nom de l'examen <span class="text-danger">*</span></label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $exam->name)); ?>" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-4">
                <label class="form-label text-14 fw-medium">Classe <span class="text-danger">*</span></label>
                <select name="class_id" class="form-select" required>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($class->id); ?>" <?php echo e(old('class_id', $exam->class_id) == $class->id ? 'selected' : ''); ?>>
                            <?php echo e($class->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-4">
                <label class="form-label text-14 fw-medium">Année scolaire <span class="text-danger">*</span></label>
                <select name="academic_year_id" class="form-select" required>
                    <?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($year->id); ?>" <?php echo e(old('academic_year_id', $exam->academic_year_id) == $year->id ? 'selected' : ''); ?>>
                            <?php echo e($year->label); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['academic_year_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-4">
                <label class="form-label text-14 fw-medium">Période <span class="text-danger">*</span></label>
                <select name="term" class="form-select" required>
                    <option value="first" <?php echo e(old('term', $exam->term) == 'first' ? 'selected' : ''); ?>>Premier semestre</option>
                    <option value="second" <?php echo e(old('term', $exam->term) == 'second' ? 'selected' : ''); ?>>Deuxième semestre</option>
                    <option value="third" <?php echo e(old('term', $exam->term) == 'third' ? 'selected' : ''); ?>>Troisième semestre</option>
                    <option value="final" <?php echo e(old('term', $exam->term) == 'final' ? 'selected' : ''); ?>>Final</option>
                </select>
                <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-4">
                <label class="form-label text-14 fw-medium">Type d'examen <span class="text-danger">*</span></label>
                <select name="exam_type" class="form-select" required>
                    <option value="midterm" <?php echo e(old('exam_type', $exam->exam_type) == 'midterm' ? 'selected' : ''); ?>>Mi-période</option>
                    <option value="final" <?php echo e(old('exam_type', $exam->exam_type) == 'final' ? 'selected' : ''); ?>>Final</option>
                    <option value="quiz" <?php echo e(old('exam_type', $exam->exam_type) == 'quiz' ? 'selected' : ''); ?>>Quiz</option>
                    <option value="assignment" <?php echo e(old('exam_type', $exam->exam_type) == 'assignment' ? 'selected' : ''); ?>>Devoir</option>
                </select>
                <?php $__errorArgs = ['exam_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-2">
                <label class="form-label text-14 fw-medium">Note de passage</label>
                <input type="number" step="0.5" name="passing_mark" class="form-control" value="<?php echo e(old('passing_mark', $exam->passing_mark)); ?>">
                <?php $__errorArgs = ['passing_mark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-2">
                <label class="form-label text-14 fw-medium">Note totale</label>
                <input type="number" step="0.5" name="total_mark" class="form-control" value="<?php echo e(old('total_mark', $exam->total_mark ?? 100)); ?>">
                <?php $__errorArgs = ['total_mark'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-3">
                <label class="form-label text-14 fw-medium">Date début</label>
                <input type="date" name="start_date" class="form-control" value="<?php echo e(old('start_date', $exam->start_date ? $exam->start_date->format('Y-m-d') : '')); ?>">
                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-md-3">
                <label class="form-label text-14 fw-medium">Date fin</label>
                <input type="date" name="end_date" class="form-control" value="<?php echo e(old('end_date', $exam->end_date ? $exam->end_date->format('Y-m-d') : '')); ?>">
                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-danger small"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
    </div>

    <div class="d-flex gap-12 justify-content-end">
        <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" class="btn btn-outline-secondary rounded-pill px-24">Annuler</a>
        <button type="submit" class="btn bg-main-600 text-white rounded-pill px-24">Mettre à jour</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\exams\edit.blade.php ENDPATH**/ ?>