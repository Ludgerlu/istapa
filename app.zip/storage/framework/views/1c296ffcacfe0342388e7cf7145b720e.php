
<?php $__env->startSection('title', 'Créer une classe'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Nouvelle classe</h4></div>
<form action="<?php echo e(route('admin.classes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-3">
            <div class="col-md-6"><label>Nom *</label><input type="text" name="name" class="form-control" required></div>
            <div class="col-md-6"><label>Section</label><input type="text" name="section" class="form-control"></div>
            <div class="col-md-4"><label>Programme *</label><select name="program_id" class="form-select" required><?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>"><?php echo e($p->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Année scolaire *</label><select name="academic_year_id" class="form-select" required><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($y->id); ?>"><?php echo e($y->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Capacité</label><input type="number" name="capacity" class="form-control"></div>
            <div class="col-md-12"><label>Professeur principal</label><select name="head_teacher_id" class="form-select"><option value="">-- Aucun --</option><?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($t->user_id); ?>"><?php echo e($t->user->first_name); ?> <?php echo e($t->user->last_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24"><a href="<?php echo e(route('admin.classes.index')); ?>" class="btn btn-outline-secondary">Annuler</a><button type="submit" class="btn btn-main">Créer</button></div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\classes\create.blade.php ENDPATH**/ ?>