
<?php $__env->startSection('title', 'Modifier la présence'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Modifier la session du <?php echo e($attendance->session_date->format('d/m/Y')); ?></h4></div>

<form method="POST" action="<?php echo e(route('admin.attendances.update', $attendance)); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="bg-white rounded-10 p-24 mb-24">
        <div class="row g-3">
            <div class="col-md-4">
                <label>Classe *</label>
                <select name="class_id" id="class_id" class="form-select" required>
                    <option value="">-- Sélectionner --</option>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($class->id); ?>" <?php echo e($attendance->class_id == $class->id ? 'selected' : ''); ?>><?php echo e($class->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Matière *</label>
                <select name="subject_id" id="subject_id" class="form-select" required>
                    <option value="">-- Choisir --</option>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>" <?php echo e($attendance->subject_id == $subject->id ? 'selected' : ''); ?>><?php echo e($subject->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Date *</label>
                <input type="date" name="session_date" class="form-control" required value="<?php echo e($attendance->session_date->format('Y-m-d')); ?>">
            </div>
            <div class="col-md-2">
                <label>Heure début</label>
                <input type="time" name="start_time" class="form-control" value="<?php echo e($attendance->start_time ? \Carbon\Carbon::parse($attendance->start_time)->format('H:i') : ''); ?>">
            </div>
            <div class="col-md-2">
                <label>Heure fin</label>
                <input type="time" name="end_time" class="form-control" value="<?php echo e($attendance->end_time ? \Carbon\Carbon::parse($attendance->end_time)->format('H:i') : ''); ?>">
            </div>
            <div class="col-md-12">
                <label>Notes</label>
                <textarea name="notes" class="form-control" rows="2"><?php echo e($attendance->notes); ?></textarea>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-10 p-24">
        <h5 class="mb-16">Liste des élèves</h5>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="bg-main-25">
                    <tr><th>Élève</th><th>Statut</th><th>Commentaire</th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $presenceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($student->name); ?> <br><small class="text-muted"><?php echo e($student->matricule); ?></small></td>
                        <td>
                            <select name="students[<?php echo e($student->id); ?>][status]" class="form-select" required>
                                <option value="present" <?php echo e($student->status == 'present' ? 'selected' : ''); ?>>Présent</option>
                                <option value="absent" <?php echo e($student->status == 'absent' ? 'selected' : ''); ?>>Absent</option>
                                <option value="late" <?php echo e($student->status == 'late' ? 'selected' : ''); ?>>En retard</option>
                                <option value="excused" <?php echo e($student->status == 'excused' ? 'selected' : ''); ?>>Excusé</option>
                            </select>
                            <input type="hidden" name="students[<?php echo e($student->id); ?>][id]" value="<?php echo e($student->id); ?>">
                        </td>
                        <td><input type="text" name="students[<?php echo e($student->id); ?>][comment]" class="form-control" value="<?php echo e($student->comment); ?>"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-end gap-12">
            <button type="submit" class="btn btn-main rounded-pill px-30">Mettre à jour</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\attendances\edit.blade.php ENDPATH**/ ?>