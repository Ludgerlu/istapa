

<?php $__env->startSection('title', $academicYear->label); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0"><?php echo e($academicYear->label); ?></h4>
    <div>
        <a href="<?php echo e(route('admin.academic-years.edit', $academicYear)); ?>" class="btn btn-main rounded-pill"><i class="ph ph-pencil"></i> Modifier</a>
        <a href="<?php echo e(route('admin.academic-years.index')); ?>" class="btn btn-outline-secondary rounded-pill">Retour</a>
    </div>
</div>

<div class="bg-white rounded-10 p-24 mb-24">
    <div class="row">
        <div class="col-md-6">
            <p><strong>Date début :</strong> <?php echo e($academicYear->start_date->format('d/m/Y')); ?></p>
            <p><strong>Date fin :</strong> <?php echo e($academicYear->end_date->format('d/m/Y')); ?></p>
        </div>
        <div class="col-md-6">
            <p><strong>Année en cours :</strong>
                <?php if($academicYear->is_current): ?>
                    <span class="badge bg-success-600">Oui</span>
                <?php else: ?>
                    <span class="badge bg-neutral-400">Non</span>
                <?php endif; ?>
            </p>
            <p><strong>Classes associées :</strong> <?php echo e($academicYear->classes_count ?? 0); ?></p>
            <p><strong>Frais associés :</strong> <?php echo e($academicYear->fees_count ?? 0); ?></p>
            <p><strong>Examens associés :</strong> <?php echo e($academicYear->exams_count ?? 0); ?></p>
        </div>
    </div>
</div>

<?php if(($academicYear->classes_count ?? 0) > 0): ?>
<div class="bg-white rounded-10 p-24">
    <h5>Classes rattachées</h5>
    <div class="overflow-x-auto">
        <table class="table table-sm">
            <thead>
                <tr><th>Nom de la classe</th><th>Section</th><th>Programme</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $academicYear->classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($class->name); ?></td>
                    <td><?php echo e($class->section ?? '—'); ?></td>
                    <td><?php echo e($class->program->name ?? '—'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\academic-years\show.blade.php ENDPATH**/ ?>