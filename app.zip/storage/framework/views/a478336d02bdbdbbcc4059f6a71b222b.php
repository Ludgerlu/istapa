

<?php $__env->startSection('title', 'Années académiques'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Années académiques</h4>
    <a href="<?php echo e(route('admin.academic-years.create')); ?>" class="btn btn-main rounded-pill"><i class="ph ph-plus-circle"></i> Nouvelle année</a>
</div>

<div class="bg-white rounded-10 p-24">
    <div class="overflow-x-auto">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr>
                    <th>Libellé</th>
                    <th>Date début</th>
                    <th>Date fin</th>
                    <th>Année en cours</th>
                    <th>Classes</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($year->label); ?></td>
                    <td><?php echo e($year->start_date->format('d/m/Y')); ?></td>
                    <td><?php echo e($year->end_date->format('d/m/Y')); ?></td>
                    <td>
                        <?php if($year->is_current): ?>
                            <span class="badge bg-success-600"><i class="ph ph-check-circle"></i> Actuelle</span>
                        <?php else: ?>
                            <span class="badge bg-neutral-400">—</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($year->classes_count ?? $year->classes->count() ?? 0); ?></td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.academic-years.show', $year)); ?>" class="btn btn-sm btn-outline-secondary"><i class="ph ph-eye"></i></a>
                        <a href="<?php echo e(route('admin.academic-years.edit', $year)); ?>" class="btn btn-sm btn-outline-secondary"><i class="ph ph-pencil"></i></a>
                        <form action="<?php echo e(route('admin.academic-years.destroy', $year)); ?>" method="POST" onsubmit="return confirm('Supprimer cette année académique ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-40 text-muted">Aucune année académique enregistrée.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="mt-24 d-flex justify-content-end">
        <?php echo e($academicYears->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\academic-years\index.blade.php ENDPATH**/ ?>