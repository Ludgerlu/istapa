

<?php $__env->startSection('title', 'Demandes de congé'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Demandes de congé</h4>
    <div>
        <a href="<?php echo e(route('admin.leaves.index')); ?>" class="btn bg-main-600 rounded-pill">Toutes</a>
        <a href="<?php echo e(route('admin.leaves.index', ['status' => 'pending'])); ?>" class="btn bg-main-600 rounded-pill">En attente</a>
        <a href="<?php echo e(route('admin.leaves.index', ['status' => 'approved'])); ?>" class="btn bg-main-600 rounded-pill">Approuvées</a>
        <a href="<?php echo e(route('admin.leaves.index', ['status' => 'rejected'])); ?>" class="btn bg-main-600 rounded-pill">Refusées</a>
    </div>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-4">
            <label>Élève (nom)</label>
            <input type="text" name="student_name" class="form-control" placeholder="Nom de l'élève" value="<?php echo e(request('student_name')); ?>">
        </div>
        <div class="col-md-3">
            <label>Statut</label>
            <select name="status" class="form-select">
                <option value="">Tous</option>
                <option value="pending" <?php echo e(request('status')=='pending' ? 'selected' : ''); ?>>En attente</option>
                <option value="approved" <?php echo e(request('status')=='approved' ? 'selected' : ''); ?>>Approuvé</option>
                <option value="rejected" <?php echo e(request('status')=='rejected' ? 'selected' : ''); ?>>Refusé</option>
            </select>
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-main w-100">Filtrer</button>
        </div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <div class="overflow-x-auto">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr><th>Élève</th><th>Type</th><th>Période</th><th>Motif</th><th>Date demande</th><th>Statut</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($leave->student->user->first_name ?? ''); ?> <?php echo e($leave->student->user->last_name ?? ''); ?></td>
                    <td><?php echo e(ucfirst($leave->leave_type)); ?></td>
                    <td><?php echo e($leave->start_date->format('d/m/Y')); ?> → <?php echo e($leave->end_date->format('d/m/Y')); ?></td>
                    <td><?php echo e(Str::limit($leave->reason, 50)); ?></td>
                    <td><?php echo e($leave->created_at->format('d/m/Y')); ?></td>
                    <td>
                        <?php if($leave->status == 'pending'): ?>
                            <span class="badge bg-warning-600">En attente</span>
                        <?php elseif($leave->status == 'approved'): ?>
                            <span class="badge bg-success-600">Approuvé</span>
                        <?php else: ?>
                            <span class="badge bg-danger-600">Refusé</span>
                        <?php endif; ?>
                    </td>
                    <td class="d-flex gap-8">
                        <!-- <a href="<?php echo e(route('admin.leaves.show', $leave)); ?>" class="btn btn-sm btn-outline-secondary"><i class="ph ph-eye"></i></a> -->
                        <?php if($leave->status == 'pending'): ?>
                            <button type="button" class="btn btn-sm bg-success-600" data-bs-toggle="modal" data-bs-target="#approveModal-<?php echo e($leave->id); ?>"><i class="ph ph-check"></i> Approuver</button>
                            <button type="button" class="btn btn-sm bg-danger-600" data-bs-toggle="modal" data-bs-target="#rejectModal-<?php echo e($leave->id); ?>"><i class="ph ph-x"></i> Refuser</button>
                        <?php endif; ?>
                        <form action="<?php echo e(route('admin.leaves.destroy', $leave)); ?>" method="POST" onsubmit="return confirm('Supprimer définitivement cette demande ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm bg-danger-600"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>

                
                <?php if($leave->status == 'pending'): ?>
                <div class="modal fade" id="approveModal-<?php echo e($leave->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form action="<?php echo e(route('admin.leaves.approve', $leave)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header bg-success-100">
                                    <h5 class="modal-title">Approuver la demande</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong><?php echo e($leave->student->user->first_name ?? ''); ?> <?php echo e($leave->student->user->last_name ?? ''); ?></strong> – <?php echo e($leave->leave_type); ?></p>
                                    <div class="mb-3">
                                        <label>Commentaire (optionnel)</label>
                                        <textarea name="comment" class="form-control" rows="2"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn bg-danger-600" data-bs-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn bg-success-600">Confirmer l'approbation</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal fade" id="rejectModal-<?php echo e($leave->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form action="<?php echo e(route('admin.leaves.reject', $leave)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header bg-danger-100">
                                    <h5 class="modal-title">Refuser la demande</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong><?php echo e($leave->student->user->first_name ?? ''); ?> <?php echo e($leave->student->user->last_name ?? ''); ?></strong></p>
                                    <div class="mb-3">
                                        <label>Motif du refus *</label>
                                        <textarea name="comment" class="form-control" rows="3" required></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn bg-main-600" data-bs-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn bg-danger-600">Confirmer le refus</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="text-center py-40">Aucune demande de congé trouvée.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($leaves->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\leaves\index.blade.php ENDPATH**/ ?>