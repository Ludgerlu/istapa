
<?php $__env->startSection('title', $exam->name); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4><?php echo e($exam->name); ?></h4>
    <div><a href="<?php echo e(route('admin.exams.edit', $exam)); ?>" class="btn btn-main">Modifier</a> <a href="<?php echo e(route('admin.exams.index')); ?>" class="btn bg-danger-600">Retour</a></div>
</div>

<div class="bg-white rounded-10 p-24 mb-24">
    <div class="row">
        <div class="col-md-3"><strong>Classe :</strong> <?php echo e($exam->class->name); ?></div>
        <div class="col-md-3"><strong>Année :</strong> <?php echo e($exam->academicYear->label); ?></div>
        <div class="col-md-3"><strong>Période :</strong> <?php echo e(ucfirst($exam->term)); ?></div>
        <div class="col-md-3"><strong>Type :</strong> <?php echo e(ucfirst($exam->exam_type)); ?></div>
        <div class="col-md-3"><strong>Dates :</strong> <?php echo e($exam->start_date?->format('d/m/Y')); ?> → <?php echo e($exam->end_date?->format('d/m/Y')); ?></div>
        <div class="col-md-3"><strong>Note passage :</strong> <?php echo e($exam->passing_mark ?? '—'); ?></div>
        <div class="col-md-3"><strong>Note totale :</strong> <?php echo e($exam->total_mark ?? '100'); ?></div>
    </div>
</div>

<div class="bg-white rounded-10 p-24 mb-24">
    <h5>Matières de l'examen</h5>
    <?php if($exam->examSubjects->count()): ?>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr><th>Matière</th><th>Date épreuve</th><th>Horaire</th><th>Note totale</th><th>Moyenne</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $exam->examSubjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $examSubject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $marks = $examSubject->marks; $avg = $marks->avg('mark'); ?>
                <tr>
                    <td><?php echo e($examSubject->subject->name); ?> (<?php if($examSubject->subject->coefficient): ?> coeff <?php echo e($examSubject->subject->coefficient); ?> <?php endif; ?>)</td>
                    <td><?php echo e($examSubject->exam_date?->format('d/m/Y') ?? '—'); ?></td>
                    <td><?php echo e($examSubject->start_time ? \Carbon\Carbon::parse($examSubject->start_time)->format('H:i') : '—'); ?> - <?php echo e($examSubject->end_time ? \Carbon\Carbon::parse($examSubject->end_time)->format('H:i') : '—'); ?></td>
                    <td><?php echo e($examSubject->total_mark ?? $exam->total_mark ?? '—'); ?></td>
                    <td><?php if($marks->count()): ?> <?php echo e(number_format($avg, 2)); ?> (<?php echo e($marks->count()); ?>/<?php echo e($exam->class->classEnrollments->count() ?? 0); ?> notes) <?php else: ?> — <?php endif; ?></td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.exam-subjects.marks.edit', $examSubject)); ?>" class="btn btn-sm bg-primary-400">Saisir notes</a>
                        <form action="<?php echo e(route('admin.exams.subjects.destroy', $examSubject)); ?>" method="POST" onsubmit="return confirm('Retirer cette matière ?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm bg-danger-600"><i class="ph ph-trash"></i></button></form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
    <p class="text-muted">Aucune matière ajoutée à cet examen.</p>
    <?php endif; ?>

    <hr class="my-24">
    <h5>Ajouter une matière</h5>
    <form action="<?php echo e(route('admin.exams.subjects.store', $exam)); ?>" method="POST" class="row g-3 align-items-end">
        <?php echo csrf_field(); ?>
        <div class="col-md-3"><label>Matière</label><select name="subject_id" class="form-select" required><?php $__currentLoopData = $exam->class->subjects ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($subj->id); ?>"><?php echo e($subj->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-2"><label>Date</label><input type="date" name="exam_date" class="form-control"></div>
        <div class="col-md-2"><label>Début</label><input type="time" name="start_time" class="form-control"></div>
        <div class="col-md-2"><label>Fin</label><input type="time" name="end_time" class="form-control"></div>
        <div class="col-md-2"><label>Total</label><input type="number" name="total_mark" class="form-control" placeholder="100"></div>
        <div class="col-md-1"><button type="submit" class="btn btn-main">Ajouter</button></div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\exams\show.blade.php ENDPATH**/ ?>