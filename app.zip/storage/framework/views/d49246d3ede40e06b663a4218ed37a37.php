
<?php $__env->startSection('title', 'Modifier la matière'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Modifier : <?php echo e($subject->name); ?></h4></div>
<form action="<?php echo e(route('admin.subjects.update', $subject)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-3">
            <div class="col-md-6">
                <label>Nom *</label>
                <input type="text" name="name" class="form-control" value="<?php echo e(old('name', $subject->name)); ?>" required>
            </div>
            <div class="col-md-6">
                <label>Code</label>
                <input type="text" name="code" class="form-control" value="<?php echo e(old('code', $subject->code)); ?>">
            </div>
            <div class="col-md-4">
                <label>Classe *</label>
                <select name="class_id" class="form-select" required>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($c->id); ?>" <?php echo e(old('class_id', $subject->class_id)==$c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label>Enseignant</label>
                <select name="teacher_id" class="form-select">
                    <option value="">-- Aucun --</option>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($t->user_id); ?>" <?php echo e(old('teacher_id', $subject->teacher_id)==$t->user_id ? 'selected' : ''); ?>><?php echo e($t->user->first_name); ?> <?php echo e($t->user->last_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label>Coefficient</label>
                <input type="number" step="0.5" name="coefficient" class="form-control" value="<?php echo e(old('coefficient', $subject->coefficient)); ?>">
            </div>
            <div class="col-md-2">
                <label>Heures/semaine</label>
                <input type="number" step="0.5" name="hours_per_week" class="form-control" value="<?php echo e(old('hours_per_week', $subject->hours_per_week)); ?>">
            </div>
            <div class="col-md-12">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="3"><?php echo e(old('description', $subject->description)); ?></textarea>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24">
        <a href="<?php echo e(route('admin.subjects.show', $subject)); ?>" class="btn bg-danger-600 rounded-pill">Annuler</a>
        <button type="submit" class="btn btn-main rounded-pill">Mettre à jour</button>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\subjects\edit.blade.php ENDPATH**/ ?>