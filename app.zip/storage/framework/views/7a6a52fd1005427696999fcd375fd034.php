<?php $__env->startSection('title', 'Attendance — ' . $student->name); ?>
<?php $__env->startSection('page-title', $student->name . ' — Attendance report'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('attendance.index')); ?>" class="btn">← Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


<form method="GET" style="display:flex;gap:8px;align-items:center;margin-bottom:1.25rem">
    <label style="font-size:13px;color:#888780">Month:</label>
    <input type="month" name="month" value="<?php echo e($month); ?>" onchange="this.form.submit()" style="width:180px">
</form>


<?php
    $present = $records->where('status','present')->count();
    $absent  = $records->where('status','absent')->count();
    $late    = $records->where('status','late')->count();
?>
<div class="stats-grid" style="max-width:600px">
    <div class="stat-card">
        <div class="stat-label">Rate</div>
        <div class="stat-value <?php echo e($rate >= 80 ? 'green' : ($rate >= 60 ? 'amber' : 'red')); ?>"><?php echo e($rate); ?>%</div>
        <div class="progress" style="margin-top:8px">
            <div class="progress-bar <?php echo e($rate >= 80 ? 'bg-green' : ($rate >= 60 ? 'bg-amber' : 'bg-red')); ?>"
                 style="width:<?php echo e($rate); ?>%"></div>
        </div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Present days</div>
        <div class="stat-value green"><?php echo e($present); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Absent days</div>
        <div class="stat-value red"><?php echo e($absent); ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Late arrivals</div>
        <div class="stat-value amber"><?php echo e($late); ?></div>
    </div>
</div>


<div class="card">
    <div class="card-title" style="margin-bottom:1rem"><?php echo e($start->format('F Y')); ?> calendar</div>

    <div class="att-calendar">
        
        <?php $__currentLoopData = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="text-align:center;font-size:10px;color:#888780;padding:4px 0"><?php echo e($d); ?></div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php $startDow = $start->dayOfWeekIso - 1; ?>
        <?php for($i = 0; $i < $startDow; $i++): ?>
            <div></div>
        <?php endfor; ?>

        
        <?php for($day = 1; $day <= $end->day; $day++): ?>
            <?php
                $date   = $start->copy()->setDay($day);
                $key    = $date->format('Y-m-d');
                $isWknd = $date->isWeekend();
                $rec    = $records[$key] ?? null;
                $status = $isWknd ? 'H' : ($rec ? strtoupper(substr($rec->status, 0, 1)) : '—');
                $css    = match($status) {
                    'P' => 'att-P', 'A' => 'att-A',
                    'L' => 'att-L', 'H' => 'att-H',
                    default => ''
                };
            ?>
            <div class="att-day <?php echo e($css); ?>" title="<?php echo e($date->format('d M')); ?>">
                <div style="font-size:9px;margin-bottom:2px;opacity:.7"><?php echo e($day); ?></div>
                <?php echo e($status); ?>

            </div>
        <?php endfor; ?>
    </div>

    
    <div style="display:flex;gap:12px;margin-top:.75rem;flex-wrap:wrap">
        <span style="font-size:12px;display:flex;align-items:center;gap:5px">
            <span class="badge badge-green">P</span> Present
        </span>
        <span style="font-size:12px;display:flex;align-items:center;gap:5px">
            <span class="badge badge-red">A</span> Absent
        </span>
        <span style="font-size:12px;display:flex;align-items:center;gap:5px">
            <span class="badge badge-amber">L</span> Late
        </span>
        <span style="font-size:12px;display:flex;align-items:center;gap:5px">
            <span class="badge badge-gray">H</span> Holiday / Weekend
        </span>
    </div>
</div>


<?php if($records->whereIn('status', ['absent','late'])->count()): ?>
<div class="card">
    <div class="card-title" style="margin-bottom:1rem">Absences & late arrivals</div>
    <table>
        <thead>
            <tr><th>Date</th><th>Status</th><th>Note</th></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $records->whereIn('status', ['absent','late'])->sortBy('date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($rec->date)->format('d M Y')); ?></td>
                    <td>
                        <span class="badge <?php echo e($rec->status === 'absent' ? 'badge-red' : 'badge-amber'); ?>">
                            <?php echo e(ucfirst($rec->status)); ?>

                        </span>
                    </td>
                    <td style="color:#888780"><?php echo e($rec->note ?? '—'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\attendances\student-report.blade.php ENDPATH**/ ?>