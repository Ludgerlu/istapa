

<?php $__env->startSection('title', 'Événements'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-24 flex-wrap gap-12">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Événements</h4>
    <a href="<?php echo e(route('admin.events.create')); ?>" class="btn px-20 py-10 bg-main-600 text-white rounded-pill">
        <i class="ph ph-plus-circle"></i> Nouvel événement
    </a>
</div>

<div class="bg-white rounded-10 px-20 py-16 mb-4">
    <form action="<?php echo e(route('admin.events.index')); ?>" method="GET" class="d-flex gap-12 flex-wrap align-items-center">
        <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Rechercher…" class="form-control text-14" style="max-width:250px">
        <select name="status" class="form-select w-auto">
            <option value="">Tous</option>
            <option value="published" <?php echo e(request('status')=='published' ? 'selected' : ''); ?>>Publiés</option>
            <option value="draft" <?php echo e(request('status')=='draft' ? 'selected' : ''); ?>>Brouillons</option>
        </select>
        <button type="submit" class="btn bg-main-600 text-white rounded-pill px-20">Filtrer</button>
        <?php if(request()->anyFilled(['q','status'])): ?>
            <a href="<?php echo e(route('admin.events.index')); ?>" class="text-neutral-400">Réinitialiser</a>
        <?php endif; ?>
    </form>
</div>

<div class="bg-white rounded-10 px-24 py-24">
    <div class="overflow-x-auto">
        <table class="table">
            <thead>
                <tr><th>Titre</th><th>Date</th><th>Lieu</th><th>Statut</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td>
                        <div class="d-flex align-items-center gap-12">
                            <?php if($event->cover_image): ?>
                                <img src="<?php echo e(asset('storage/'.$event->cover_image)); ?>" width="50" height="40" class="rounded-8 object-fit-cover">
                            <?php else: ?>
                                <div class="rounded-8 bg-main-25 d-flex align-items-center justify-content-center" style="width:50px;height:40px">
                                    <i class="ph ph-calendar text-main-600"></i>
                                </div>
                            <?php endif; ?>
                            <span><?php echo e($event->title); ?></span>
                        </div>
                    </td>
                    <td><?php echo e($event->start_date->format('d/m/Y')); ?> <?php if($event->start_time): ?> <?php echo e($event->start_time); ?> <?php endif; ?></td>
                    <td><?php echo e($event->location ?: '—'); ?></td>
                    <td><?php if($event->is_published): ?> <span class="badge bg-success-100 text-success-600">Publié</span> <?php else: ?> <span class="badge bg-neutral-100 text-neutral-500">Brouillon</span> <?php endif; ?></td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.events.show', $event)); ?>" class="w-32 h-32 rounded-circle border border-neutral-40 d-flex align-items-center justify-content-center text-neutral-500 hover-bg-main-600 hover-text-white transition-03"><i class="ph ph-eye"></i></a>
                        <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="w-32 h-32 rounded-circle border border-neutral-40 d-flex align-items-center justify-content-center text-neutral-500 hover-bg-main-600 hover-text-white transition-03"><i class="ph ph-pencil"></i></a>
                        <form action="<?php echo e(route('admin.events.destroy', $event)); ?>" method="POST" onsubmit="return confirm('Supprimer ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="w-32 h-32 rounded-circle border border-neutral-40 d-flex align-items-center justify-content-center text-neutral-500 hover-bg-danger hover-text-white transition-03 bg-transparent"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center py-40 text-neutral-400">Aucun événement.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($events->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\events\index.blade.php ENDPATH**/ ?>