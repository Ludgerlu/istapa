
<?php $__env->startSection('title', 'Créer un examen'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Nouvel examen</h4></div>
<form action="<?php echo e(route('admin.exams.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-3">
            <div class="col-md-6"><label>Nom *</label><input type="text" name="name" class="form-control" required></div>
            <div class="col-md-3"><label>Classe *</label><select name="class_id" class="form-select" required><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-3"><label>Année scolaire *</label><select name="academic_year_id" class="form-select" required><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($y->id); ?>"><?php echo e($y->label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-3"><label>Période</label><select name="term" class="form-select"><option value="first">Premier semestre</option><option value="second">Deuxième semestre</option><option value="third">Troisième semestre</option><option value="final">Final</option></select></div>
            <div class="col-md-3"><label>Type d'examen</label><select name="exam_type" class="form-select"><option value="midterm">Mi-période</option><option value="final">Final</option><option value="quiz">Quiz</option><option value="assignment">Devoir</option></select></div>
            <div class="col-md-2"><label>Note de passage</label><input type="number" name="passing_mark" class="form-control" step="0.5"></div>
            <div class="col-md-2"><label>Note totale</label><input type="number" name="total_mark" class="form-control" step="0.5" value="100"></div>
            <div class="col-md-3"><label>Date début</label><input type="date" name="start_date" class="form-control"></div>
            <div class="col-md-3"><label>Date fin</label><input type="date" name="end_date" class="form-control"></div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24"><a href="<?php echo e(route('admin.exams.index')); ?>" class="btn btn-outline-secondary">Annuler</a><button type="submit" class="btn btn-main">Créer</button></div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\exams\create.blade.php ENDPATH**/ ?>