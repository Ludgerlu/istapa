<?php $__env->startSection('title', 'Fees — ' . $student->name); ?>
<?php $__env->startSection('page-title', $student->name . ' — Fee details'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('fees.index')); ?>" class="btn">← Back</a>
    <a href="<?php echo e(route('fees.create-payment')); ?>?student_id=<?php echo e($student->id); ?>" class="btn btn-primary">+ Record payment</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if($fee): ?>
    <?php
        $balance = $fee->total_amount - $fee->amount_paid;
        $rate    = $fee->total_amount > 0 ? round(($fee->amount_paid / $fee->total_amount) * 100) : 0;
        $statusBadge = ['paid' => 'badge-green', 'partial' => 'badge-amber', 'unpaid' => 'badge-red'];
    ?>

    
    <div class="stats-grid" style="max-width:600px">
        <div class="stat-card">
            <div class="stat-label">Total fees</div>
            <div class="stat-value"><?php echo e(number_format($fee->total_amount)); ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Paid</div>
            <div class="stat-value green"><?php echo e(number_format($fee->amount_paid)); ?></div>
        </div>
        <div class="stat-card">
            <div class="stat-label">Balance</div>
            <div class="stat-value <?php echo e($balance > 0 ? 'red' : 'green'); ?>"><?php echo e(number_format($balance)); ?></div>
        </div>
    </div>

    <div class="card" style="max-width:600px;margin-bottom:1rem">
        <div style="display:flex;justify-content:space-between;margin-bottom:6px">
            <span style="font-size:13px;color:#888780">Payment progress</span>
            <div style="display:flex;align-items:center;gap:8px">
                <span style="font-size:13px;font-weight:500"><?php echo e($rate); ?>%</span>
                <span class="badge <?php echo e($statusBadge[$fee->status] ?? 'badge-gray'); ?>"><?php echo e(ucfirst($fee->status)); ?></span>
            </div>
        </div>
        <div class="progress" style="height:10px">
            <div class="progress-bar <?php echo e($rate >= 100 ? 'bg-green' : ($rate > 0 ? 'bg-amber' : 'bg-red')); ?>"
                 style="width:<?php echo e($rate); ?>%"></div>
        </div>
    </div>

    
    <div class="card">
        <div class="card-title" style="margin-bottom:1rem">Payment history</div>
        <?php if($payments->count()): ?>
            <table>
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Method</th>
                        <th>Reference</th>
                        <th>Notes</th>
                        <th>Receipt</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($payment->paid_at->format('d M Y')); ?></td>
                            <td style="font-weight:500"><?php echo e(number_format($payment->amount)); ?> FCFA</td>
                            <td>
                                <?php
                                    $methodLabel = ['cash'=>'Cash','mobile_money'=>'Mobile Money','bank_transfer'=>'Bank transfer','cheque'=>'Cheque'];
                                ?>
                                <span class="badge badge-gray"><?php echo e($methodLabel[$payment->method] ?? $payment->method); ?></span>
                            </td>
                            <td style="color:#888780"><?php echo e($payment->reference ?? '—'); ?></td>
                            <td style="color:#888780"><?php echo e($payment->notes ?? '—'); ?></td>
                            <td>
                                <a href="<?php echo e(route('fees.receipt', $payment)); ?>" class="btn btn-sm" target="_blank">
                                    🖨 Print
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="color:#888780;font-size:13px">No payments recorded yet.</p>
        <?php endif; ?>
    </div>

<?php else: ?>
    <div class="card">
        <p style="color:#888780;font-size:13px;margin-bottom:1rem">
            No fee record found for <?php echo e($student->name); ?> this academic year.
        </p>
        <a href="<?php echo e(route('fees.create-payment')); ?>?student_id=<?php echo e($student->id); ?>" class="btn btn-primary">
            Record first payment
        </a>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\fees\student.blade.php ENDPATH**/ ?>