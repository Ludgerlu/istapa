
<?php $__env->startSection('title', 'Saisie des notes - ' . $examSubject->subject->name); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24">
    <h4>Saisie des notes : <?php echo e($examSubject->subject->name); ?></h4>
    <p>Examen : <?php echo e($examSubject->exam->name); ?> | Classe : <?php echo e($examSubject->exam->class->name); ?> | Note totale : <?php echo e($examSubject->total_mark ?? $examSubject->exam->total_mark ?? 100); ?></p>
</div>

<form action="<?php echo e(route('admin.exam-subjects.marks.update', $examSubject)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead class="bg-main-25">
                    <tr><th>Élève</th><th>Matricule</th><th>Note / <?php echo e($examSubject->total_mark ?? $examSubject->exam->total_mark ?? 100); ?></th><th>Commentaire</th></tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enrollment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $student = $enrollment->student; $mark = $marks->get($student->user_id); ?>
                    <tr>
                        <td><?php echo e($student->user->first_name); ?> <?php echo e($student->user->last_name); ?></td>
                        <td><?php echo e($student->matricule ?? '—'); ?></td>
                        <td>
                            <input type="number" step="0.01" name="marks[<?php echo e($student->user_id); ?>]" class="form-control" value="<?php echo e($mark ? $mark->mark : ''); ?>" min="0" max="<?php echo e($examSubject->total_mark ?? $examSubject->exam->total_mark ?? 100); ?>">
                         </td>
                        <td><input type="text" name="comments[<?php echo e($student->user_id); ?>]" class="form-control" value="<?php echo e($mark ? $mark->comment : ''); ?>"></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="d-flex justify-content-end gap-12 mt-24">
            <a href="<?php echo e(route('admin.exams.show', $examSubject->exam_id)); ?>" class="btn bg-danger-600">Annuler</a>
            <button type="submit" class="btn btn-main">Enregistrer les notes</button>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\exams\marks.blade.php ENDPATH**/ ?>