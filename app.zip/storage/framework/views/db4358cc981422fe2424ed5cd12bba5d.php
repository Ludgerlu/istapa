

<?php $__env->startSection('title', 'Demandes d\'admission'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Demandes d'admission</h4>
    <div>
        <a href="<?php echo e(route('admin.admissions.index')); ?>" class="btn bg-main-600 rounded-pill">Toutes</a>
        <a href="<?php echo e(route('admin.admissions.index', ['status' => 'pending'])); ?>" class="btn bg-main-600 rounded-pill">En attente</a>
        <a href="<?php echo e(route('admin.admissions.index', ['status' => 'approved'])); ?>" class="btn bg-main-600 rounded-pill">Approuvées</a>
        <a href="<?php echo e(route('admin.admissions.index', ['status' => 'rejected'])); ?>" class="btn bg-main-600 rounded-pill">Refusées</a>
    </div>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-4">
            <label>Rechercher</label>
            <input type="text" name="q" class="form-control" placeholder="Nom, email, référence..." value="<?php echo e(request('q')); ?>">
        </div>
        <div class="col-md-3">
            <label>Statut</label>
            <select name="status" class="form-select">
                <option value="">Tous</option>
                <option value="pending" <?php echo e(request('status')=='pending' ? 'selected' : ''); ?>>En attente</option>
                <option value="approved" <?php echo e(request('status')=='approved' ? 'selected' : ''); ?>>Approuvé</option>
                <option value="rejected" <?php echo e(request('status')=='rejected' ? 'selected' : ''); ?>>Refusé</option>
            </select>
        </div>
        <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-main w-100">Filtrer</button>
        </div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <div class="overflow-x-auto">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr><th>Référence</th><th>Nom complet</th><th>Email</th><th>Téléphone</th><th>Programme</th><th>Date</th><th>Statut</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($admission->reference_code); ?></td>
                    <td><?php echo e($admission->first_name); ?> <?php echo e($admission->last_name); ?></td>
                    <td><?php echo e($admission->email); ?></td>
                    <td><?php echo e($admission->phone); ?></td>
                    <td><?php echo e($admission->program->name ?? '—'); ?></td>
                    <td><?php echo e($admission->created_at->format('d/m/Y')); ?></td>
                    <td>
                        <?php if($admission->status == 'pending'): ?>
                            <span class="badge bg-warning-600">En attente</span>
                        <?php elseif($admission->status == 'approved'): ?>
                            <span class="badge bg-success-600">Approuvé</span>
                        <?php else: ?>
                            <span class="badge bg-danger-600">Refusé</span>
                        <?php endif; ?>
                    </td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.admissions.show', $admission)); ?>" class="btn btn-sm bg-main-600"><i class="ph ph-eye"></i></a>
                        <?php if($admission->status == 'pending'): ?>
                            <button type="button" class="btn btn-sm bg-success-600" data-bs-toggle="modal" data-bs-target="#approveModal-<?php echo e($admission->id); ?>"><i class="ph ph-check"></i> Approuver</button>
                            <button type="button" class="btn btn-sm bg-danger-600" data-bs-toggle="modal" data-bs-target="#rejectModal-<?php echo e($admission->id); ?>"><i class="ph ph-x"></i> Refuser</button>
                        <?php endif; ?>
                        <form action="<?php echo e(route('admin.admissions.destroy', $admission)); ?>" method="POST" onsubmit="return confirm('Supprimer définitivement cette demande ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm bg-danger-600"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>

                
                <?php if($admission->status == 'pending'): ?>
                <div class="modal fade" id="approveModal-<?php echo e($admission->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form action="<?php echo e(route('admin.admissions.approve', $admission)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header bg-success-100">
                                    <h5 class="modal-title">Approuver la demande</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong><?php echo e($admission->first_name); ?> <?php echo e($admission->last_name); ?></strong> (<?php echo e($admission->email); ?>)</p>
                                    <div class="mb-3">
                                        <label>Commentaire (optionnel)</label>
                                        <textarea name="comment" class="form-control" rows="2"></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-main-600" data-bs-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn btn-warning-600">Confirmer l'approbation</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal fade" id="rejectModal-<?php echo e($admission->id); ?>" tabindex="-1">
                    <div class="modal-dialog">
                        <form action="<?php echo e(route('admin.admissions.reject', $admission)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-content">
                                <div class="modal-header bg-danger-100">
                                    <h5 class="modal-title">Refuser la demande</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <p><strong><?php echo e($admission->first_name); ?> <?php echo e($admission->last_name); ?></strong></p>
                                    <div class="mb-3">
                                        <label>Motif du refus *</label>
                                        <textarea name="comment" class="form-control" rows="3" required></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn bg-main-600" data-bs-dismiss="modal">Annuler</button>
                                    <button type="submit" class="btn bg-danger-600">Confirmer le refus</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center py-40">Aucune demande trouvée.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($admissions->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istapa/public_html/resources/views/admin/admissions/index.blade.php ENDPATH**/ ?>