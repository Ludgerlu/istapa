
<?php $__env->startSection('title', 'Détails du frais'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Frais : <?php echo e($fee->category->name); ?> - <?php echo e($fee->class->name); ?></h4>
    <div><a href="<?php echo e(route('admin.fees.edit', $fee)); ?>" class="btn btn-main">Modifier</a></div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="bg-white rounded-10 p-24 mb-24">
            <h5>Informations générales</h5>
            <table class="table table-borderless">
                <tr><th>Classe</th><td><?php echo e($fee->class->name); ?></td></tr>
                <tr><th>Année scolaire</th><td><?php echo e($fee->academicYear->name); ?></td></tr>
                <tr><th>Catégorie</th><td><?php echo e($fee->category->name); ?></td></tr>
                <tr><th>Montant</th><td><?php echo e(number_format($fee->amount, 2)); ?> FCFA</td></tr>
                <tr><th>Échéance</th><td><?php echo e($fee->due_date?->format('d/m/Y') ?? 'Non définie'); ?></td></tr>
                <tr><th>Description</th><td><?php echo e($fee->description ?: 'Aucune'); ?></td></tr>
            </table>
        </div>
    </div>
    <div class="col-md-6">
        <div class="bg-white rounded-10 p-24 mb-24">
            <h5>Récapitulatif des paiements</h5>
            <p><strong>Total payé :</strong> <?php echo e(number_format($totalPaid, 2)); ?> FCFA</p>
            <p><strong>Reste à payer :</strong> <?php echo e(number_format($remaining, 2)); ?> FCFA</p>
            <p><strong>Statut :</strong> 
                <?php if($remaining <= 0): ?> <span class="badge bg-success-100 text-success-600">Soldé</span>
                <?php elseif($totalPaid > 0): ?> <span class="badge bg-warning-100 text-warning-600">Partiel</span>
                <?php else: ?> <span class="badge bg-danger-100 text-danger-600">Impayé</span>
                <?php endif; ?>
            </p>
        </div>
    </div>
</div>

<div class="bg-white rounded-10 p-24">
    <h5>Historique des paiements</h5>
    <?php if($fee->payments->count()): ?>
    <table class="table">
        <thead><tr><th>Élève</th><th>Montant payé</th><th>Méthode</th><th>Référence</th><th>Date</th><th>Reçu par</th></tr></thead>
        <tbody>
            <?php $__currentLoopData = $fee->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($payment->student->user->first_name); ?> <?php echo e($payment->student->user->last_name ?? 'N/A'); ?></td>
                <td><?php echo e(number_format($payment->amount_paid, 2)); ?> FCFA</td>
                <td><?php echo e($payment->payment_method); ?></td>
                <td><?php echo e($payment->transaction_ref ?? '—'); ?></td>
                <td><?php echo e($payment->paid_on->format('d/m/Y')); ?></td>
                <td><?php echo e($payment->receivedBy->name ?? '—'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <div class="text-center py-40 text-muted">Aucun paiement enregistré pour ce frais.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\fees\show.blade.php ENDPATH**/ ?>