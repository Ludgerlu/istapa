<div class="table-responsive">
    <table class="table table-sm table-bordered">
        <thead class="bg-main-25">
            <tr><th>Élève</th><th>Statut</th><th>Commentaire</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $presenceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $student = $item['student']; ?>
            <tr>
                <td><?php echo e($student->user->first_name ?? ''); ?> <?php echo e($student->user->last_name ?? ''); ?><br><small class="text-muted"><?php echo e($student->matricule ?? ''); ?></small></td>
                <td>
                    <?php switch($item['status']):
                        case ('present'): ?> <span class="badge bg-success-600">Présent</span> <?php break; ?>
                        <?php case ('absent'): ?> <span class="badge bg-danger-600">Absent</span> <?php break; ?>
                        <?php case ('late'): ?> <span class="badge bg-warning-600">En retard</span> <?php break; ?>
                        <?php case ('excused'): ?> <span class="badge bg-info-600">Excusé</span> <?php break; ?>
                        <?php default: ?> <span class="badge bg-secondary">Non renseigné</span>
                    <?php endswitch; ?>
                </td>
                <td><?php echo e($item['comment'] ?? '—'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="text-center">Aucun élève inscrit dans cette classe.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div><?php /**PATH D:\pros\istapa\resources\views\admin\classes\presence.blade.php ENDPATH**/ ?>