<?php $__env->startSection('title', 'Gestion des présences'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Sessions de présence</h4>
    <a href="<?php echo e(route('admin.attendances.create')); ?>" class="btn btn-main rounded-pill"><i class="ph ph-plus-circle"></i> Nouvelle présence</a>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-3"><label>Classe</label><select name="class_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php echo e(request('class_id')==$c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-3"><label>Matière</label><select name="subject_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($s->id); ?>" <?php echo e(request('subject_id')==$s->id ? 'selected' : ''); ?>><?php echo e($s->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-2"><label>Du</label><input type="date" name="date_from" class="form-control" value="<?php echo e(request('date_from')); ?>"></div>
        <div class="col-md-2"><label>Au</label><input type="date" name="date_to" class="form-control" value="<?php echo e(request('date_to')); ?>"></div>
        <div class="col-md-2 d-flex align-items-end"><button type="submit" class="btn btn-main w-100">Filtrer</button></div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <div class="overflow-x-auto">
        <table class="table">
            <thead class="bg-main-25">
                <td><th>Classe</th><th>Matière</th><th>Date</th><th>Horaire</th><th>Enregistré par</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($session->class->name ?? '—'); ?></td>
                    <td><?php echo e($session->subject->name ?? '—'); ?></td>
                    <td><?php echo e($session->session_date->format('d/m/Y')); ?></td>
                    <td><?php echo e($session->start_time ? \Carbon\Carbon::parse($session->start_time)->format('H:i') : '—'); ?> - <?php echo e($session->end_time ? \Carbon\Carbon::parse($session->end_time)->format('H:i') : '—'); ?></td>
                    <td><?php echo e($session->takenBy->first_name ?? ''); ?> <?php echo e($session->takenBy->last_name ?? ''); ?></td>
                    <td class="d-flex gap-8">
                        <a href="<?php echo e(route('admin.attendances.show', $session)); ?>" class="btn btn-sm btn-outline-secondary"><i class="ph ph-eye"></i></a>
                        <a href="<?php echo e(route('admin.attendances.edit', $session)); ?>" class="btn btn-sm btn-outline-secondary"><i class="ph ph-pencil"></i></a>
                        <form action="<?php echo e(route('admin.attendances.destroy', $session)); ?>" method="POST" onsubmit="return confirm('Supprimer cette session ?')">
                            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-sm btn-outline-danger"><i class="ph ph-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center py-40">Aucune session de présence. <a href="<?php echo e(route('admin.attendances.create')); ?>">Créer la première</a></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($sessions->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\attendances\index.blade.php ENDPATH**/ ?>