<?php $__env->startSection('title', 'Gestion des frais'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Frais scolaires</h4>
    <a href="<?php echo e(route('admin.fees.create')); ?>" class="btn btn-main rounded-pill"><i class="ph ph-plus"></i> Nouveau frais</a>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-3"><label>Classe</label><select name="class_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php echo e(request('class_id')==$c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-3"><label>Année scolaire</label><select name="academic_year_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($y->id); ?>" <?php echo e(request('academic_year_id')==$y->id ? 'selected' : ''); ?>><?php echo e($y->label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-3"><label>Catégorie</label><select name="fee_category_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($cat->id); ?>" <?php echo e(request('fee_category_id')==$cat->id ? 'selected' : ''); ?>><?php echo e($cat->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-main w-100">Filtrer</button></div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <table class="table">
        <thead><tr><th>Classe</th><th>Année scolaire</th><th>Catégorie</th><th>Montant</th><th>Échéance</th><th>Actions</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $fees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($fee->class->name ?? '—'); ?></td>
                <td><?php echo e($fee->academicYear->name ?? '—'); ?></td>
                <td><?php echo e($fee->category->name ?? '—'); ?></td>
                <td><?php echo e(number_format($fee->amount, 2)); ?> FCFA</td>
                <td><?php echo e($fee->due_date?->format('d/m/Y') ?? '—'); ?></td>
                <td class="d-flex gap-8">
                    <a href="<?php echo e(route('admin.fees.show', $fee)); ?>" class="btn bg-main-600 text-white px-12 py-6 rounded-pill text-12"><i class="ph ph-eye"></i></a>
                    <a href="<?php echo e(route('admin.fees.edit', $fee)); ?>" class="btn btn-sm bg-warning-100 text-warning-600 px-12 py-6 rounded-pill text-12"><i class="ph ph-pencil"></i></a>
                    <form action="<?php echo e(route('admin.fees.destroy', $fee)); ?>" method="POST" onsubmit="return confirm('Supprimer définitivement ?')">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm bg-danger-100 text-danger-600 px-12 py-6 rounded-pill text-12"><i class="ph ph-trash"></i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="6" class="text-center py-40 text-muted">Aucun frais enregistré.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($fees->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istapa/public_html/resources/views/admin/fees/index.blade.php ENDPATH**/ ?>