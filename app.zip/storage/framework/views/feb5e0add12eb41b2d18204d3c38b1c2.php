

<?php $__env->startSection('title', $subject->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-24">
    <h4 class="fw-semibold text-neutral-500 text-20 mb-0">Matière : <?php echo e($subject->name); ?></h4>
    <div>
        <a href="<?php echo e(route('admin.subjects.edit', $subject)); ?>" class="btn btn-main rounded-pill"><i class="ph ph-pencil"></i> Modifier</a>
        <a href="<?php echo e(route('admin.subjects.index')); ?>" class="btn btn-outline-secondary rounded-pill">Retour</a>
    </div>
</div>

<div class="bg-white rounded-10 p-24 mb-24">
    <div class="row">
        <div class="col-md-3"><strong>Code :</strong><br><?php echo e($subject->code ?? '—'); ?></div>
        <div class="col-md-3"><strong>Classe :</strong><br><?php echo e($subject->class->name ?? '—'); ?></div>
        <div class="col-md-3"><strong>Enseignant :</strong><br><?php echo e($subject->teacher->user->full_name ?? 'Non assigné'); ?></div>
        <div class="col-md-3"><strong>Coefficient :</strong><br><?php echo e($subject->coefficient ?? '—'); ?></div>
        <div class="col-md-3"><strong>Heures/semaine :</strong><br><?php echo e($subject->hours_per_week ?? '—'); ?></div>
        <div class="col-md-12 mt-3"><strong>Description :</strong><br><?php echo e($subject->description ?: 'Aucune description'); ?></div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="bg-white rounded-10 p-24 mb-24">
            <h5>Examens utilisant cette matière</h5>
            <?php if($exams->count()): ?>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr><th>Examen</th><th>Type</th><th>Période</th><th>Date épreuve</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $examSubject = $subject->examSubjects->where('exam_id', $exam->id)->first();
                        ?>
                        <tr>
                            <td><a href="<?php echo e(route('admin.exams.show', $exam)); ?>"><?php echo e($exam->name); ?></a></td>
                            <td><?php echo e(ucfirst($exam->exam_type)); ?></td>
                            <td><?php echo e($exam->term); ?></td>
                            <td><?php echo e($examSubject && $examSubject->exam_date ? $examSubject->exam_date->format('d/m/Y') : '—'); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-muted">Cette matière n'est utilisée dans aucun examen.</p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="bg-white rounded-10 p-24">
            <h5>Sessions de présence</h5>
            <?php if($attendanceSessions->count()): ?>
            <div class="table-responsive">
                <table class="table table-sm table-bordered">
                    <thead>
                        <tr><th>Date</th><th>Horaire</th><th>Enseignant</th><th>Actions</th></tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $attendanceSessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($session->session_date->format('d/m/Y')); ?></td>
                            <td><?php echo e($session->start_time ? \Carbon\Carbon::parse($session->start_time)->format('H:i') : '—'); ?> - <?php echo e($session->end_time ? \Carbon\Carbon::parse($session->end_time)->format('H:i') : '—'); ?></td>
                            <td><?php echo e($session->takenBy->full_name ?? '—'); ?></td>
                            <td><a href="<?php echo e(route('admin.attendances.show', $session)); ?>" class="btn btn-sm bg-main-600">Détails</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-16 d-flex justify-content-end">
                <?php echo e($attendanceSessions->links()); ?>

            </div>
            <?php else: ?>
            <p class="text-muted">Aucune session de présence pour cette matière.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\subjects\show.blade.php ENDPATH**/ ?>