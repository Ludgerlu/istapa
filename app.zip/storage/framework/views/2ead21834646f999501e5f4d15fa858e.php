<?php $__env->startSection('title', 'Fee Structure'); ?>
<?php $__env->startSection('page-title', 'Fee Structure'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('fees.index')); ?>" class="btn">← Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('fees.update-structure')); ?>">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <div class="card">
        <div class="card-header">
            <span class="card-title">Academic year <?php echo e(config('school.academic_year', '2025/2026')); ?></span>
            <button type="submit" class="btn btn-primary">Save changes</button>
        </div>

        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>Class</th>
                        <th>Tuition (FCFA)</th>
                        <th>Dev levy (FCFA)</th>
                        <th>Exam fees (FCFA)</th>
                        <th>PTA (FCFA)</th>
                        <th>Total (FCFA)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $structures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $struct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="structures[<?php echo e($i); ?>][id]" value="<?php echo e($struct->id); ?>">
                        <tr>
                            <td style="font-weight:500"><?php echo e($struct->class_level); ?></td>
                            <td>
                                <input type="number" name="structures[<?php echo e($i); ?>][tuition]"
                                       value="<?php echo e($struct->tuition); ?>" min="0"
                                       style="width:120px" onchange="recalcTotal(<?php echo e($i); ?>)">
                            </td>
                            <td>
                                <input type="number" name="structures[<?php echo e($i); ?>][dev_levy]"
                                       value="<?php echo e($struct->dev_levy); ?>" min="0"
                                       style="width:120px" onchange="recalcTotal(<?php echo e($i); ?>)">
                            </td>
                            <td>
                                <input type="number" name="structures[<?php echo e($i); ?>][exam_fees]"
                                       value="<?php echo e($struct->exam_fees); ?>" min="0"
                                       style="width:120px" onchange="recalcTotal(<?php echo e($i); ?>)">
                            </td>
                            <td>
                                <input type="number" name="structures[<?php echo e($i); ?>][pta]"
                                       value="<?php echo e($struct->pta); ?>" min="0"
                                       style="width:100px" onchange="recalcTotal(<?php echo e($i); ?>)">
                            </td>
                            <td>
                                <span id="total-<?php echo e($i); ?>" style="font-weight:500">
                                    <?php echo e(number_format($struct->total)); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="card">
        <div class="card-title" style="margin-bottom:1rem">Payment instalments</div>
        <table style="max-width:500px">
            <thead>
                <tr><th>Instalment</th><th>Percentage</th><th>Deadline</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>1st instalment</td>
                    <td><span class="badge badge-blue">50%</span></td>
                    <td style="color:#888780">15 September 2025</td>
                </tr>
                <tr>
                    <td>2nd instalment</td>
                    <td><span class="badge badge-blue">30%</span></td>
                    <td style="color:#888780">15 January 2026</td>
                </tr>
                <tr>
                    <td>Balance</td>
                    <td><span class="badge badge-blue">20%</span></td>
                    <td style="color:#888780">30 March 2026</td>
                </tr>
            </tbody>
        </table>
    </div>
</form>

<script>
function recalcTotal(i) {
    const get = name => parseFloat(document.querySelector(`input[name="structures[${i}][${name}]"]`).value) || 0;
    const total = get('tuition') + get('dev_levy') + get('exam_fees') + get('pta');
    document.getElementById('total-' + i).textContent = total.toLocaleString();
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\fees\structure.blade.php ENDPATH**/ ?>