
<?php $__env->startSection('title', 'Examens'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Examens</h4>
    <a href="<?php echo e(route('admin.exams.create')); ?>" class="btn btn-main rounded-pill"><i class="ph ph-plus-circle"></i> Nouvel examen</a>
</div>

<div class="bg-white rounded-10 p-20 mb-24">
    <form method="GET" class="row g-3">
        <div class="col-md-3"><label>Classe</label><select name="class_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c->id); ?>" <?php echo e(request('class_id')==$c->id ? 'selected' : ''); ?>><?php echo e($c->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-3"><label>Année scolaire</label><select name="academic_year_id" class="form-select"><option value="">Toutes</option><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($y->id); ?>" <?php echo e(request('academic_year_id')==$y->id ? 'selected' : ''); ?>><?php echo e($y->label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="col-md-3"><label>Période</label><select name="term" class="form-select"><option value="">Toutes</option><option value="first" <?php echo e(request('term')=='first' ? 'selected' : ''); ?>>Premier semestre</option><option value="second" <?php echo e(request('term')=='second' ? 'selected' : ''); ?>>Deuxième semestre</option><option value="third" <?php echo e(request('term')=='third' ? 'selected' : ''); ?>>Troisième semestre</option><option value="final" <?php echo e(request('term')=='final' ? 'selected' : ''); ?>>Final</option></select></div>
        <div class="col-md-3 d-flex align-items-end"><button type="submit" class="btn btn-main w-100">Filtrer</button></div>
    </form>
</div>

<div class="bg-white rounded-10 p-24">
    <table class="table table-bordered">
        <thead class="bg-main-25"><tr><th>Nom</th><th>Classe</th><th>Année scolaire</th><th>Période</th><th>Type</th><th>Dates</th><th>Actions</th></tr></thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($exam->name); ?></td>
                <td><?php echo e($exam->class->name ?? '—'); ?></td>
                <td><?php echo e($exam->academicYear->label ?? '—'); ?></td>
                <td><?php echo e(ucfirst($exam->term)); ?></td>
                <td><?php echo e(ucfirst($exam->exam_type)); ?></td>
                <td><?php echo e($exam->start_date ? $exam->start_date->format('d/m/Y') : '—'); ?> → <?php echo e($exam->end_date ? $exam->end_date->format('d/m/Y') : '—'); ?></td>
                <td class="d-flex gap-8">
                    <a href="<?php echo e(route('admin.exams.show', $exam)); ?>" class="btn btn-sm bg-main-600"><i class="ph ph-eye"></i></a>
                    <a href="<?php echo e(route('admin.exams.edit', $exam)); ?>" class="btn btn-sm bg-main-600"><i class="ph ph-pencil"></i></a>
                    <form action="<?php echo e(route('admin.exams.destroy', $exam)); ?>" method="POST" onsubmit="return confirm('Supprimer cet examen ?')"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn btn-sm bg-danger-600"><i class="ph ph-trash"></i></button></form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="7" class="text-center py-40">Aucun examen trouvé. <a href="<?php echo e(route('admin.exams.create')); ?>">Créer le premier</a></td></tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php echo e($exams->withQueryString()->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\exams\index.blade.php ENDPATH**/ ?>