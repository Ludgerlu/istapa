

<?php $__env->startSection('title', 'Détails de présence'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-24">
    <h4>Détails de la session</h4>
    <div>
        <a href="<?php echo e(route('admin.attendances.edit', $attendance)); ?>" class="btn btn-main rounded-pill"><i class="ph ph-pencil"></i> Modifier</a>
        <a href="<?php echo e(route('admin.attendances.index')); ?>" class="btn btn-outline-secondary rounded-pill">Retour à la liste</a>
    </div>
</div>

<div class="bg-white rounded-10 p-24 mb-24">
    <div class="row">
        <div class="col-md-4"><strong>Classe :</strong> <?php echo e($attendance->class->name ?? '—'); ?></div>
        <div class="col-md-4"><strong>Matière :</strong> <?php echo e($attendance->subject->name ?? '—'); ?></div>
        <div class="col-md-4"><strong>Date :</strong> <?php echo e($attendance->session_date->format('d/m/Y')); ?></div>
        <div class="col-md-4"><strong>Horaire :</strong> <?php echo e($attendance->start_time ? \Carbon\Carbon::parse($attendance->start_time)->format('H:i') : '—'); ?> - <?php echo e($attendance->end_time ? \Carbon\Carbon::parse($attendance->end_time)->format('H:i') : '—'); ?></div>
        <div class="col-md-4"><strong>Enregistré par :</strong> <?php echo e($attendance->takenBy->first_name ?? ''); ?> <?php echo e($attendance->takenBy->last_name ?? ''); ?></div>
        <?php if($attendance->notes): ?><div class="col-md-12"><strong>Notes :</strong> <?php echo e($attendance->notes); ?></div><?php endif; ?>
    </div>
</div>

<div class="bg-white rounded-10 p-24">
    <h5 class="mb-16">Liste des présences</h5>
    <div class="table-responsive">
        <table class="table table-bordered">
            <thead class="bg-main-25">
                <tr><th>Élève</th><th>Statut</th><th>Commentaire</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $presenceList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->student->user->first_name ?? ''); ?> <?php echo e($item->student->user->last_name ?? ''); ?><br><small class="text-muted"><?php echo e($item->student->matricule ?? ''); ?></small></td>
                    <td>
                        <?php switch($item->status):
                            case ('present'): ?> <span class="badge bg-success-600">Présent</span> <?php break; ?>
                            <?php case ('absent'): ?> <span class="badge bg-danger-600">Absent</span> <?php break; ?>
                            <?php case ('late'): ?> <span class="badge bg-warning-600">En retard</span> <?php break; ?>
                            <?php case ('excused'): ?> <span class="badge bg-info-600">Excusé</span> <?php break; ?>
                            <?php default: ?> <span class="badge bg-secondary">Non renseigné</span>
                        <?php endswitch; ?>
                    </td>
                    <td><?php echo e($item->comment ?? '—'); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="3" class="text-center">Aucune donnée de présence.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/istapa/public_html/resources/views/admin/attendances/show.blade.php ENDPATH**/ ?>