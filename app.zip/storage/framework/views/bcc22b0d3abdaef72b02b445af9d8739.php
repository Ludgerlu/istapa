<?php $__env->startSection('title', 'Class Summary'); ?>
<?php $__env->startSection('page-title', 'Class Summary'); ?>

<?php $__env->startSection('topbar-actions'); ?>
    <a href="<?php echo e(route('attendance.index')); ?>" class="btn">← Back</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<form method="GET" style="display:flex;gap:8px;align-items:center;margin-bottom:1.25rem">
    <label style="font-size:13px;color:#888780">Month:</label>
    <input type="month" name="month" value="<?php echo e($month); ?>" onchange="this.form.submit()" style="width:180px">
</form>

<div class="card">
    <div class="card-title" style="margin-bottom:1rem">
        Attendance by class — <?php echo e(\Carbon\Carbon::parse($month . '-01')->format('F Y')); ?>

    </div>
    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Class</th>
                    <th>Students</th>
                    <th>Avg rate</th>
                    <th style="min-width:160px">Progress</th>
                    <th>Present</th>
                    <th>Absent</th>
                    <th>Trend</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $summary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $rate   = $row['rate'];
                        $color  = $rate >= 85 ? 'green' : ($rate >= 70 ? 'amber' : 'red');
                        $barCls = 'bg-' . $color;
                        $badgeCls = 'badge-' . $color;
                    ?>
                    <tr>
                        <td style="font-weight:500"><?php echo e($row['class']->name); ?></td>
                        <td><?php echo e($row['class']->students_count); ?></td>
                        <td><span class="badge <?php echo e($badgeCls); ?>"><?php echo e($rate); ?>%</span></td>
                        <td>
                            <div class="progress">
                                <div class="progress-bar <?php echo e($barCls); ?>" style="width:<?php echo e($rate); ?>%"></div>
                            </div>
                        </td>
                        <td style="color:#3B6D11"><?php echo e($row['present']); ?></td>
                        <td style="color:#A32D2D"><?php echo e($row['absent']); ?></td>
                        <td>
                            <?php if($rate >= 85): ?>
                                <span style="color:#3B6D11">↑ Good</span>
                            <?php elseif($rate >= 70): ?>
                                <span style="color:#854F0B">→ Watch</span>
                            <?php else: ?>
                                <span style="color:#A32D2D">↓ Alert</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\attendances\class-summary.blade.php ENDPATH**/ ?>