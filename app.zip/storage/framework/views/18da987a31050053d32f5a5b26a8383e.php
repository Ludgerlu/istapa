
<?php $__env->startSection('title', 'Modifier la classe'); ?>
<?php $__env->startSection('content'); ?>
<div class="mb-24"><h4>Modifier : <?php echo e($class->name); ?></h4></div>
<form action="<?php echo e(route('admin.classes.update', $class)); ?>" method="POST">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="bg-white rounded-10 p-24">
        <div class="row g-3">
            <div class="col-md-6"><label>Nom *</label><input type="text" name="name" class="form-control" value="<?php echo e(old('name', $class->name)); ?>" required></div>
            <div class="col-md-6"><label>Section</label><input type="text" name="section" class="form-control" value="<?php echo e(old('section', $class->section)); ?>"></div>
            <div class="col-md-4"><label>Programme *</label><select name="program_id" class="form-select" required><?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($p->id); ?>" <?php echo e(old('program_id', $class->program_id)==$p->id ? 'selected' : ''); ?>><?php echo e($p->title_fr); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Année scolaire *</label><select name="academic_year_id" class="form-select" required><?php $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($y->id); ?>" <?php echo e(old('academic_year_id', $class->academic_year_id)==$y->id ? 'selected' : ''); ?>><?php echo e($y->label); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="col-md-4"><label>Capacité</label><input type="number" name="capacity" class="form-control" value="<?php echo e(old('capacity', $class->capacity)); ?>"></div>
            <div class="col-md-12"><label>Professeur principal</label><select name="head_teacher_id" class="form-select"><option value="">-- Aucun --</option><?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($t->user_id); ?>" <?php echo e(old('head_teacher_id', $class->head_teacher_id)==$t->user_id ? 'selected' : ''); ?>><?php echo e($t->user->first_name); ?> <?php echo e($t->user->last_name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        </div>
    </div>
    <div class="d-flex justify-content-end gap-12 mt-24"><a href="<?php echo e(route('admin.classes.show', $class)); ?>" class="btn bg-danger-600 rounded-pill">Annuler</a><button type="submit" class="btn btn-main rounded-pill">Mettre à jour</button></div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\pros\istapa\resources\views\admin\classes\edit.blade.php ENDPATH**/ ?>