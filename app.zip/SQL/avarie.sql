-- ============================================================
-- Migration : Création de la table visit_damaged_products
-- Base de données : easy_mtrade
-- Date : 2026-02-24
-- Rôle : Stocker les produits avariés détectés lors des visites merchandiser
-- Règle métier : Maximum 3 produits avariés par visite
-- ============================================================

-- Vérifier que la table n'existe pas avant création
CREATE TABLE IF NOT EXISTS `visit_damaged_products` (
    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    `visit_id` BIGINT UNSIGNED NOT NULL COMMENT 'Référence vers la visite',
    `product_id` INT UNSIGNED NOT NULL COMMENT 'Produit SABC avarié',
    `photo_path` VARCHAR(500) NOT NULL COMMENT 'Chemin de la photo du produit avarié (obligatoire)',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    PRIMARY KEY (`id`),

    -- Clés étrangères (types alignés sur les tables existantes)
    -- visits.id = BIGINT UNSIGNED, products.id = INT UNSIGNED
    CONSTRAINT `fk_damaged_visit` 
        FOREIGN KEY (`visit_id`) REFERENCES `visits`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_damaged_product` 
        FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE RESTRICT,

    -- Index pour performances
    INDEX `idx_damaged_visit_id` (`visit_id`),
    INDEX `idx_damaged_product_id` (`product_id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='Produits avariés détectés lors des visites merchandiser (max 3 par visite)';


-- ============================================================
-- ROLLBACK : Suppression de la table (en cas de besoin)
-- ============================================================
-- DROP TABLE IF EXISTS `visit_damaged_products`;