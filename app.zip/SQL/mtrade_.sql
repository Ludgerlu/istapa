-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 04 fév. 2026 à 13:33
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `mtrade`
--
CREATE DATABASE IF NOT EXISTS `mtrade` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `mtrade`;

DELIMITER $$
--
-- Procédures
--
DROP PROCEDURE IF EXISTS `calculate_pdv_sovi`$$
CREATE DEFINER=`easy`@`localhost` PROCEDURE `calculate_pdv_sovi` (IN `pdv_id_param` BIGINT)   BEGIN
    SELECT 
        p.name AS pdv_name,
        vs.category,
        AVG(vs.sovi_sabc) AS avg_sovi_sabc,
        AVG(vs.sovi_sp) AS avg_sovi_sp,
        AVG(vs.sovi_ucb_autres) AS avg_sovi_ucb
    FROM pdv p
    JOIN visits v ON p.id = v.pdv_id
    JOIN visit_sovi vs ON v.id = vs.visit_id
    WHERE p.id = pdv_id_param AND v.status = 'validated'
    GROUP BY p.name, vs.category;
END$$

DROP PROCEDURE IF EXISTS `generate_weekly_report`$$
CREATE DEFINER=`easy`@`localhost` PROCEDURE `generate_weekly_report` (IN `user_id_param` BIGINT, IN `week_start` DATE)   BEGIN
    DECLARE week_end DATE;
    SET week_end = DATE_ADD(week_start, INTERVAL 7 DAY);
    
    SELECT 
        v.visit_date,
        p.name AS pdv_name,
        v.arrival_time,
        v.departure_time,
        v.status,
        COUNT(DISTINCT vs.id) AS stocks_recorded,
        AVG(vsovi.sovi_sabc) AS avg_sovi,
        COUNT(DISTINCT vio.id) AS violations
    FROM visits v
    JOIN pdv p ON v.pdv_id = p.id
    LEFT JOIN visit_stocks vs ON v.id = vs.visit_id
    LEFT JOIN visit_sovi vsovi ON v.id = vsovi.visit_id
    LEFT JOIN violations vio ON v.id = vio.visit_id
    WHERE v.user_id = user_id_param
      AND v.visit_date BETWEEN week_start AND week_end
    GROUP BY v.id, v.visit_date, p.name, v.arrival_time, v.departure_time, v.status
    ORDER BY v.visit_date;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `action` varchar(100) NOT NULL COMMENT 'create, update, delete, login, etc.',
  `entity_type` varchar(50) NOT NULL COMMENT 'visits, users, pdv, etc.',
  `entity_id` bigint(20) UNSIGNED DEFAULT NULL,
  `old_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Valeur avant modification' CHECK (json_valid(`old_value`)),
  `new_value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Valeur après modification' CHECK (json_valid(`new_value`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE `brands` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `company` enum('SABC','SP','UCB','Autres') NOT NULL,
  `is_competitor` tinyint(1) DEFAULT 0,
  `logo_path` varchar(500) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `brands`
--

INSERT INTO `brands` (`id`, `name`, `company`, `is_competitor`, `logo_path`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Castel', 'SABC', 0, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(2, 'Guinness', 'SABC', 0, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(3, 'Maltina', 'SABC', 0, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(4, 'Fanta', 'SABC', 0, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(5, 'Coca-Cola', 'SABC', 0, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(6, 'Supermont', 'SP', 1, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(7, 'Planet', 'SP', 1, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(8, 'Kadji Beer', 'UCB', 1, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(9, 'Autres', 'Autres', 1, NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12');

-- --------------------------------------------------------

--
-- Structure de la table `competitor_activities`
--

DROP TABLE IF EXISTS `competitor_activities`;
CREATE TABLE `competitor_activities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `competitor_brand_id` int(10) UNSIGNED DEFAULT NULL,
  `activity_type` enum('promotion','nouveau_produit','rupture_stock','materiel','autre') NOT NULL,
  `mechanism` text DEFAULT NULL COMMENT 'Description du mécanisme concurrent',
  `impact_level` enum('faible','moyen','eleve','critique') DEFAULT 'moyen',
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `districts`
--

DROP TABLE IF EXISTS `districts`;
CREATE TABLE `districts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Nom du district',
  `code` varchar(20) NOT NULL COMMENT 'Code unique',
  `region_id` int(10) UNSIGNED NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `districts`
--

INSERT INTO `districts` (`id`, `name`, `code`, `region_id`, `description`, `created_at`, `updated_at`) VALUES
(1, 'District Modern Trade Centre', 'DMT_CENTRE', 1, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(2, 'District Modern Trade Littoral', 'DMT_LITTORAL', 2, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12');

-- --------------------------------------------------------

--
-- Structure de la table `equipment_types`
--

DROP TABLE IF EXISTS `equipment_types`;
CREATE TABLE `equipment_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `equipment_types`
--

INSERT INTO `equipment_types` (`id`, `name`, `type`, `description`, `created_at`) VALUES
(1, 'Frigo SABC', 'frigo', NULL, '2026-01-26 02:46:12'),
(2, 'Tête de gondole', 'gondole', NULL, '2026-01-26 02:46:12'),
(3, 'PLV affiche', 'plv', NULL, '2026-01-26 02:46:12'),
(4, 'Bardage vitrine', 'bardage', NULL, '2026-01-26 02:46:12'),
(5, 'Îlot promo', 'ilot', NULL, '2026-01-26 02:46:12'),
(6, 'Présentoir', 'presentoir', NULL, '2026-01-26 15:16:35'),
(7, 'TG (Tête de Gondole)', 'tg', NULL, '2026-01-26 15:16:35'),
(8, 'Dangle', 'dangle', NULL, '2026-01-26 15:16:35'),
(9, 'Caisses', 'caisses', NULL, '2026-01-26 15:16:35'),
(10, 'Stop Rayon', 'stop_rayon', NULL, '2026-01-26 15:16:35'),
(11, 'Dérouleur', 'derouleur', NULL, '2026-01-26 15:16:35'),
(12, 'Flies Banners', 'flies_banners', NULL, '2026-01-26 15:16:35'),
(13, 'Parasol', 'parasol', NULL, '2026-01-26 15:16:35');

-- --------------------------------------------------------

--
-- Structure de la table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `notification_type` enum('rappel_visite','validation_rapport','violation_detectee','objectif_mensuel','system','autre') NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` timestamp NULL DEFAULT NULL,
  `action_url` varchar(500) DEFAULT NULL,
  `priority` enum('low','normal','high') DEFAULT 'normal',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `objectives`
--

DROP TABLE IF EXISTS `objectives`;
CREATE TABLE `objectives` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `objective_type` enum('visites_mensuelles','pdv_jour','sovi_cible','ventes','autre') NOT NULL,
  `target_value` decimal(10,2) NOT NULL,
  `current_value` decimal(10,2) DEFAULT 0.00,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `status` enum('en_cours','atteint','non_atteint','depasse') DEFAULT 'en_cours',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `pdv`
--

DROP TABLE IF EXISTS `pdv`;
CREATE TABLE `pdv` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL COMMENT 'Nom du PDV',
  `code` varchar(50) DEFAULT NULL COMMENT 'Code unique du PDV',
  `type` enum('supermarche','hypermarche','epicerie','station_service','boutique','restaurant','hotel','autre') NOT NULL,
  `address` text DEFAULT NULL COMMENT 'Adresse complète',
  `city` varchar(100) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL COMMENT 'Latitude GPS',
  `longitude` decimal(11,8) DEFAULT NULL COMMENT 'Longitude GPS',
  `phone` varchar(20) DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL COMMENT 'Nom du gérant/responsable',
  `contact_phone` varchar(20) DEFAULT NULL,
  `sector_id` int(10) UNSIGNED NOT NULL,
  `status` enum('active','inactive','temporaire','ferme') DEFAULT 'active',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `pdv`
--

INSERT INTO `pdv` (`id`, `name`, `code`, `type`, `address`, `city`, `postal_code`, `latitude`, `longitude`, `phone`, `contact_person`, `contact_phone`, `sector_id`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'Super Marché Bastos', 'PDV_001', 'supermarche', 'Bastos, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 00', 'M. Diallo', '+237 6 77 99 88 77', 1, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(2, 'Épicerie du Carrefour', 'PDV_002', 'epicerie', 'Carrefour Nlongkak', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 01', 'Mme Ngo', '+237 6 77 99 88 78', 1, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(3, 'Station Total Mvan', 'PDV_003', 'station_service', 'Mvan, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 02', 'M. Mvondo', '+237 6 77 99 88 79', 1, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(4, 'Hôtel Mont Fébé', 'PDV_004', 'hotel', 'Mont Fébé, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 03', 'M. Félicien', '+237 6 77 99 88 80', 1, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(5, 'Boutique Biyem-Assi', 'PDV_005', 'boutique', 'Biyem-Assi, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 04', 'Mme Akono', '+237 6 77 99 88 81', 1, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(6, 'Hyper Marché Madagascar', 'PDV_006', 'hypermarche', 'Madagascar, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 05', 'M. Zang', '+237 6 77 99 88 82', 2, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(7, 'Restaurant Le Cèdre', 'PDV_007', 'restaurant', 'Ngoa Ekélé, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 06', 'M. Rabih', '+237 6 77 99 88 83', 2, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(8, 'Super Marché Damas', 'PDV_008', 'supermarche', 'Damas, Yaoundé', 'Yaoundé', NULL, NULL, NULL, '+237 2 22 11 00 07', 'Mme Salamatou', '+237 6 77 99 88 84', 2, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(9, 'Super Marché Bonanjo', 'PDV_009', 'supermarche', 'Bonanjo, Douala', 'Douala', NULL, NULL, NULL, '+237 2 33 11 00 08', 'M. Bello', '+237 6 77 99 88 85', 3, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(10, 'Épicerie Akwa', 'PDV_010', 'epicerie', 'Akwa, Douala', 'Douala', NULL, NULL, NULL, '+237 2 33 11 00 09', 'Mme Diallo', '+237 6 77 99 88 86', 3, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(11, 'Station Shell Deïdo', 'PDV_011', 'station_service', 'Deïdo, Douala', 'Douala', NULL, NULL, NULL, '+237 2 33 11 00 10', 'M. Kameni', '+237 6 77 99 88 87', 3, 'active', NULL, '2026-01-15 23:28:44', '2026-01-15 23:28:44'),
(12, 'Station ludger', 'PDV_012', 'station_service', '3\r\ntexaco aeroport', 'DOUALA', '1023', 4.04063500, 9.75592600, '697272270', 'JULL', '697272270', 1, 'active', NULL, '2026-01-16 08:10:37', '2026-01-16 08:26:23');

-- --------------------------------------------------------

--
-- Structure de la table `pdv_assignments`
--

DROP TABLE IF EXISTS `pdv_assignments`;
CREATE TABLE `pdv_assignments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `pdv_id` bigint(20) UNSIGNED NOT NULL,
  `assignment_type` enum('permanent','temporary') DEFAULT 'permanent',
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `pdv_equipment`
--

DROP TABLE IF EXISTS `pdv_equipment`;
CREATE TABLE `pdv_equipment` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pdv_id` bigint(20) UNSIGNED NOT NULL,
  `equipment_type_id` int(10) UNSIGNED NOT NULL,
  `brand_name` varchar(100) DEFAULT NULL COMMENT 'Marque du matériel',
  `model` varchar(100) DEFAULT NULL,
  `serial_number` varchar(100) DEFAULT NULL,
  `installation_date` date DEFAULT NULL,
  `status` enum('bon_etat','endommage','absent','mal_utilise','hors_service') DEFAULT 'bon_etat',
  `last_inspection_date` date DEFAULT NULL,
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `performance_metrics`
--

DROP TABLE IF EXISTS `performance_metrics`;
CREATE TABLE `performance_metrics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `metric_date` date NOT NULL,
  `visits_planned` int(11) DEFAULT 0,
  `visits_completed` int(11) DEFAULT 0,
  `visit_rate` decimal(5,2) GENERATED ALWAYS AS (case when `visits_planned` > 0 then `visits_completed` / `visits_planned` * 100 else 0 end) STORED,
  `reports_submitted` int(11) DEFAULT 0,
  `reports_validated` int(11) DEFAULT 0,
  `average_sovi` decimal(5,2) DEFAULT NULL,
  `violations_detected` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `sku` varchar(50) NOT NULL COMMENT 'Code produit',
  `category_id` int(10) UNSIGNED DEFAULT NULL,
  `brand_id` int(10) UNSIGNED DEFAULT NULL,
  `type` enum('cannette_biere','eaux','bg','vin','whisky','jus','autre') NOT NULL,
  `temperature_type` enum('froid','chaud','mixte') DEFAULT 'mixte',
  `pack_size` int(11) DEFAULT NULL COMMENT 'Nombre d''unités par pack',
  `unit` varchar(20) DEFAULT NULL COMMENT 'cl, L, etc.',
  `price` decimal(10,2) DEFAULT NULL,
  `image_path` varchar(500) DEFAULT NULL,
  `status` enum('active','discontinued') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`id`, `name`, `sku`, `category_id`, `brand_id`, `type`, `temperature_type`, `pack_size`, `unit`, `price`, `image_path`, `status`, `created_at`, `updated_at`) VALUES
(1, 'PACK 12 TOP ANANAS PET 35 CL', 'TPA35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(2, 'PACK 12 TOP GRENADINE PET 35 CL', 'TPG35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(3, 'PACK 12 TOP ORANGE PET 35 CL', 'TPO35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(4, 'PACK 12 TOP PAMPLEMOUSSE PET 35 CL', 'TPP35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(5, 'PACK 12 WORLD COLA PET 35 CL', 'WCO35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(6, 'PACK 12 YOUZOU PET 35 CL PROMO', 'YOU35PP', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(7, 'PACK 12 YOUZOU PET 35 CL', 'YOU35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(8, 'PACK 12 D\'JINO COCKTAIL FRUITS', 'DJC35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(9, 'PACK 12 D\'JINO PAMPLEMOUSSE', 'DJP35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(10, 'PACK 12 D\'JINO ANANAS - PASSION FRUITS', 'DJA35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(11, 'PACK 12 D\'JINO MANGUE - GOYAVE FRUITS', 'DJM35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(12, 'PACK 12 ORANGINA PET 35CL', 'ORG35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(13, 'PACK 12 VIMTO PET 35CL', 'VIM35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(14, 'PACK 12 XXL PET 35 CL', 'XXL35P', 3, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(15, 'PACK 12 TOPTONIC 35 CL', 'TPT35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30'),
(16, 'PACK 12 SODA WATER 35 CL', 'SOD35P', 1, 1, 'bg', 'mixte', 35, 'cl', 0.00, NULL, 'active', '2026-01-16 10:36:30', '2026-01-16 10:36:30');

-- --------------------------------------------------------

--
-- Structure de la table `product_categories`
--

DROP TABLE IF EXISTS `product_categories`;
CREATE TABLE `product_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `parent_id` int(10) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `product_categories`
--

INSERT INTO `product_categories` (`id`, `name`, `slug`, `parent_id`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Cannettes Bières', 'cannettes-bieres', NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(2, 'Eaux', 'eaux', NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(3, 'Boissons Gazeuses', 'bg', NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(4, 'Vins', 'vin', NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(5, 'Whisky', 'whisky', NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(6, 'Jus', 'jus', NULL, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12');

-- --------------------------------------------------------

--
-- Structure de la table `promotions`
--

DROP TABLE IF EXISTS `promotions`;
CREATE TABLE `promotions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(200) NOT NULL,
  `promo_type` varchar(100) DEFAULT NULL COMMENT 'Type de promo (ex: ILOT/RAY, Promo Woo/youzou)',
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `pdv_id` int(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `old_price` decimal(10,2) DEFAULT NULL,
  `new_price` decimal(10,2) DEFAULT NULL,
  `discount_percentage` decimal(5,2) DEFAULT NULL,
  `mechanism` text DEFAULT NULL COMMENT 'Description du mécanisme promo',
  `status` enum('planned','active','expired','cancelled') DEFAULT 'planned',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `regions`
--

DROP TABLE IF EXISTS `regions`;
CREATE TABLE `regions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Nom de la région',
  `code` varchar(20) NOT NULL COMMENT 'Code unique (ex: CENTRE, LITTORAL)',
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `regions`
--

INSERT INTO `regions` (`id`, `name`, `code`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Centre', 'CENTRE', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(2, 'Littoral', 'LITTORAL', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Nom du rôle',
  `slug` varchar(50) NOT NULL COMMENT 'Identifiant unique du rôle',
  `description` text DEFAULT NULL COMMENT 'Description des responsabilités',
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'Permissions détaillées du rôle' CHECK (json_valid(`permissions`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `description`, `permissions`, `created_at`, `updated_at`) VALUES
(1, 'Brand Ambassador', 'brand_ambassador', 'Responsable d\'un PDV fixe avec visites quotidiennes', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(2, 'Merchandiser', 'merchandiser', 'Gestion merchandising sur plusieurs PDV', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(3, 'Superviseur Brand Ambassador', 'sba', 'Gestion des Brand Ambassador', NULL, '2026-01-26 02:46:12', '2026-02-04 11:02:26'),
(4, 'Chef de Secteur MT', 'cds_mt', 'Gestion d\'un secteur Modern Trade', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(5, 'Chef de Vente MT', 'cdv_mt', 'Gestion d\'une région Modern Trade', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(6, 'TMO Modern Trade', 'tmo_mt', 'Trade Marketing Operator - Supervision district', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(7, 'CSC Modern Trade', 'csc_mt', 'Coordination équipes commerciales', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(8, 'Sales Manager MT', 'sales_manager_mt', 'Direction commerciale Modern Trade', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(9, 'Superadmin', 'superadmin', 'Administration complète du système', NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12');

-- --------------------------------------------------------

--
-- Structure de la table `sectors`
--

DROP TABLE IF EXISTS `sectors`;
CREATE TABLE `sectors` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(100) NOT NULL COMMENT 'Nom du secteur',
  `code` varchar(20) NOT NULL COMMENT 'Code unique (ex: CD81, CD82)',
  `district_id` int(10) UNSIGNED NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `sectors`
--

INSERT INTO `sectors` (`id`, `name`, `code`, `district_id`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Secteur 1', 'CD81', 1, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(2, 'Secteur 2', 'CD82', 1, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(3, 'Secteur 3', 'CD83', 1, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12'),
(4, 'Secteur 4', 'CD84', 1, NULL, '2026-01-26 02:46:12', '2026-01-26 02:46:12');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `region_id` int(10) UNSIGNED DEFAULT NULL,
  `district_id` int(10) UNSIGNED DEFAULT NULL,
  `sector_id` int(10) UNSIGNED DEFAULT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `profile_photo` varchar(500) DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `first_name`, `last_name`, `phone`, `role_id`, `region_id`, `district_id`, `sector_id`, `status`, `profile_photo`, `last_login`, `created_at`, `updated_at`) VALUES
(1, 'admin.sabc', 'admin@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Jean', 'Admin', '+237 6 99 00 11 22', 9, 1, 1, 1, 'active', NULL, '2026-01-15 23:31:16', '2026-01-15 23:27:26', '2026-01-15 23:31:16'),
(2, 'ba.martin', 'martin.n@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Martin', 'Nkolo', '+237 6 77 11 22 33', 1, 1, 1, 2, 'active', NULL, '2026-01-15 23:31:16', '2026-01-15 23:27:26', '2026-01-16 00:07:41'),
(3, 'sime.adjara', 'estelle.k@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Adjara', 'Sime', '+237 6 88 22 33 44', 1, 1, 1, 2, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26'),
(4, 'ba.rodrigue', 'rodrigue.t@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Rodrigue', 'Tchoupa', '+237 6 55 33 44 55', 1, 2, 2, 3, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26'),
(5, 'merch.alice', 'alice.m@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Alice', 'Mvondo', '+237 6 66 44 55 66', 2, 1, 1, 1, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-16 01:07:31'),
(6, 'bile.jean', 'jean.d@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Jean Baptiste', 'Bile', '+237 6 44 55 66 77', 2, 2, 2, 2, 'inactive', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:31:16'),
(7, 'sba.marie', 'marie.c@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Marie', 'Chantal', '+237 6 33 66 77 88', 3, 1, 1, 1, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-02-04 11:02:46'),
(8, 'cds.arnaud', 'arnaud.f@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Arnaud', 'Fotso', '+237 6 22 77 88 99', 4, 1, 1, 1, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26'),
(9, 'cdv.sylvie', 'sylvie.n@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Sylvie', 'Ngono', '+237 6 11 88 99 00', 5, 1, 1, NULL, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26'),
(10, 'tmo.pierre', 'pierre.k@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Pierre', 'Kouamou', '+237 6 00 99 00 11', 6, 1, 1, NULL, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26'),
(11, 'csc.eric', 'eric.m@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Eric', 'Mbarga', '+237 6 99 00 11 22', 7, 1, 1, NULL, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26'),
(12, 'manager.fabrice', 'fabrice.l@boissons-cameroun.cm', '$2y$12$2iQ6qQLNMolJ8tndRD2s7uxauCygSgX1WfY092eBkXzhRo9.blBK.', 'Fabrice', 'Lobe', '+237 6 88 11 22 33', 8, 1, NULL, NULL, 'active', NULL, NULL, '2026-01-15 23:27:26', '2026-01-15 23:27:26');

-- --------------------------------------------------------

--
-- Structure de la table `violations`
--

DROP TABLE IF EXISTS `violations`;
CREATE TABLE `violations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `equipment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `violation_type` enum('produit_concurrent','materiel_endommage','non_respect_merchandising','hygiene','autre') NOT NULL,
  `description` text NOT NULL,
  `severity` enum('faible','moyenne','grave','critique') DEFAULT 'moyenne',
  `photo_path` varchar(500) DEFAULT NULL,
  `reported_to` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Utilisateur notifié',
  `status` enum('ouverte','en_cours','resolue','fermee') DEFAULT 'ouverte',
  `resolution_date` date DEFAULT NULL,
  `resolution_notes` text DEFAULT NULL,
  `resolved_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visits`
--

DROP TABLE IF EXISTS `visits`;
CREATE TABLE `visits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'BA ou Merchandiser',
  `pdv_id` bigint(20) UNSIGNED NOT NULL,
  `visit_date` date NOT NULL,
  `arrival_time` time DEFAULT NULL COMMENT 'Heure d''arrivée',
  `departure_time` time DEFAULT NULL COMMENT 'Heure de départ',
  `visit_type` enum('daily','weekly','spot_check','promotion','maintenance') DEFAULT 'daily',
  `status` enum('draft','submitted','validated','rejected') DEFAULT 'draft',
  `latitude` decimal(10,8) DEFAULT NULL COMMENT 'Position GPS à la soumission',
  `longitude` decimal(11,8) DEFAULT NULL,
  `gps_accuracy` decimal(6,2) DEFAULT NULL COMMENT 'Précision en mètres',
  `validated_by` bigint(20) UNSIGNED DEFAULT NULL COMMENT 'Superviseur validateur',
  `validated_at` timestamp NULL DEFAULT NULL,
  `validation_notes` text DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déclencheurs `visits`
--
DROP TRIGGER IF EXISTS `after_visit_validation`;
DELIMITER $$
CREATE TRIGGER `after_visit_validation` AFTER UPDATE ON `visits` FOR EACH ROW BEGIN
    IF NEW.status = 'validated' AND OLD.status != 'validated' THEN
        INSERT INTO performance_metrics (user_id, metric_date, visits_completed, reports_validated)
        VALUES (NEW.user_id, NEW.visit_date, 1, 1)
        ON DUPLICATE KEY UPDATE 
            visits_completed = visits_completed + 1,
            reports_validated = reports_validated + 1;
    END IF;
END
$$
DELIMITER ;
DROP TRIGGER IF EXISTS `audit_visit_changes`;
DELIMITER $$
CREATE TRIGGER `audit_visit_changes` AFTER UPDATE ON `visits` FOR EACH ROW BEGIN
    IF NEW.status != OLD.status THEN
        INSERT INTO audit_logs (user_id, action, entity_type, entity_id, old_value, new_value)
        VALUES (
            NEW.validated_by, 
            'status_change', 
            'visits', 
            NEW.id,
            JSON_OBJECT('status', OLD.status),
            JSON_OBJECT('status', NEW.status)
        );
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Structure de la table `visit_activations`
--

DROP TABLE IF EXISTS `visit_activations`;
CREATE TABLE `visit_activations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `activation_type` varchar(100) DEFAULT NULL COMMENT 'Type d''activation',
  `product_id` int(10) UNSIGNED DEFAULT NULL,
  `description` text DEFAULT NULL,
  `impact` enum('faible','moyen','eleve') DEFAULT 'moyen',
  `photo_path` varchar(500) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Activations promotionnelles réalisées par les Brand Ambassadors';

-- --------------------------------------------------------

--
-- Structure de la table `visit_ba_materials`
--

DROP TABLE IF EXISTS `visit_ba_materials`;
CREATE TABLE `visit_ba_materials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `material_type` enum('echantillon','goodie','plv','brochure','autre') NOT NULL,
  `product_id` int(10) UNSIGNED DEFAULT NULL COMMENT 'Produit concerné si applicable',
  `description` varchar(200) DEFAULT NULL,
  `quantity_distributed` int(11) DEFAULT NULL COMMENT 'Quantité distribuée',
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Matériel promotionnel utilisé par les Brand Ambassadors';

-- --------------------------------------------------------

--
-- Structure de la table `visit_ba_objectives`
--

DROP TABLE IF EXISTS `visit_ba_objectives`;
CREATE TABLE `visit_ba_objectives` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `objective_sales_influenced` int(11) DEFAULT NULL COMMENT 'Objectif de ventes influencées',
  `actual_sales_influenced` int(11) DEFAULT NULL COMMENT 'Réalisations: ventes influencées',
  `objective_products_promoted` int(11) DEFAULT NULL COMMENT 'Nombre de produits à promouvoir',
  `actual_products_promoted` int(11) DEFAULT NULL COMMENT 'Nombre de produits promus',
  `clients_engaged` int(11) DEFAULT NULL COMMENT 'Nombre de clients conseillés',
  `achievement_rate` decimal(5,2) DEFAULT NULL COMMENT 'Taux de réalisation en %',
  `notes` text DEFAULT NULL COMMENT 'Faits saillants de la journée',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Objectifs et réalisations quotidiennes des Brand Ambassadors';

-- --------------------------------------------------------

--
-- Structure de la table `visit_ba_objectives_details`
--

DROP TABLE IF EXISTS `visit_ba_objectives_details`;
CREATE TABLE `visit_ba_objectives_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_objectives_id` bigint(20) UNSIGNED NOT NULL,
  `objective_sales_influenced` int(11) DEFAULT NULL COMMENT 'objectifs de ventes influencées',
  `actual_sales_influenced` int(11) DEFAULT NULL COMMENT 'Réalisations:ventes  influencees',
  `achievement_rate` decimal(5,2) DEFAULT NULL COMMENT 'Taux de realisation en %',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visit_equipment_inspections`
--

DROP TABLE IF EXISTS `visit_equipment_inspections`;
CREATE TABLE `visit_equipment_inspections` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `equipment_id` bigint(20) UNSIGNED NOT NULL,
  `condition_status` enum('bon_etat','endommage','absent','mal_utilise') NOT NULL,
  `cleanliness` enum('propre','sale','tres_sale') DEFAULT NULL,
  `functionality` enum('fonctionnel','dysfonctionnel','hors_service') DEFAULT NULL,
  `violation_detected` tinyint(1) DEFAULT 0,
  `violation_type` varchar(200) DEFAULT NULL,
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visit_expiry_dates`
--

DROP TABLE IF EXISTS `visit_expiry_dates`;
CREATE TABLE `visit_expiry_dates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `expiry_date` date NOT NULL,
  `quantity` int(11) NOT NULL COMMENT 'Quantité concernée',
  `action_taken` enum('signale','retire','promotion','aucune') DEFAULT 'signale',
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Dates de péremption signalées par BA ou Merchandiser. Note: days_until_expiry calculé dynamiquement via DATEDIFF(expiry_date, CURDATE()) dans les requêtes';

-- --------------------------------------------------------

--
-- Structure de la table `visit_highlights`
--

DROP TABLE IF EXISTS `visit_highlights`;
CREATE TABLE `visit_highlights` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `highlight_type` enum('probleme','succes','remarque_gerant','demande_client','autre') NOT NULL,
  `description` text NOT NULL,
  `priority` enum('faible','moyenne','haute','urgente') DEFAULT 'moyenne',
  `requires_action` tinyint(1) DEFAULT 0,
  `action_taken` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visit_merchandising`
--

DROP TABLE IF EXISTS `visit_merchandising`;
CREATE TABLE `visit_merchandising` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `merchandising_type` enum('froid','chaud') NOT NULL,
  `status` enum('conforme','non_conforme') NOT NULL,
  `compliance_percentage` decimal(5,2) DEFAULT NULL,
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visit_photos`
--

DROP TABLE IF EXISTS `visit_photos`;
CREATE TABLE `visit_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `photo_type` enum('presence','merchandising','violation','sovi','equipement','promotion','autre') NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL COMMENT 'Taille en octets',
  `mime_type` varchar(50) DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `taken_at` timestamp NULL DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visit_promotions`
--

DROP TABLE IF EXISTS `visit_promotions`;
CREATE TABLE `visit_promotions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `promotion_id` int(10) UNSIGNED DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL COMMENT 'Promo active dans ce PDV?',
  `price_displayed` decimal(10,2) DEFAULT NULL COMMENT 'Prix affiché',
  `price_expected` decimal(10,2) DEFAULT NULL COMMENT 'Prix attendu',
  `compliance` tinyint(1) GENERATED ALWAYS AS (`price_displayed` = `price_expected`) STORED,
  `photo_path` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Suivi des promotions par BA et Merchandiser';

-- --------------------------------------------------------

--
-- Structure de la table `visit_sovi`
--

DROP TABLE IF EXISTS `visit_sovi`;
CREATE TABLE `visit_sovi` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `category` enum('cannettes_bieres','eaux','bg','vin','whisky') NOT NULL,
  `sovi_sabc` decimal(5,2) NOT NULL COMMENT 'Part SABC en %',
  `sovi_sp` decimal(5,2) NOT NULL COMMENT 'Part SP en %',
  `sovi_ucb` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Part UCB en %',
  `sovi_ucb_autres` decimal(5,2) NOT NULL COMMENT 'Part Autres en %',
  `total_visibility` decimal(5,2) NOT NULL DEFAULT 100.00,
  `shelf_photo_path` varchar(500) DEFAULT NULL COMMENT 'Photo du rayon',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `visit_stockouts`
--

DROP TABLE IF EXISTS `visit_stockouts`;
CREATE TABLE `visit_stockouts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `quantity_affected` int(11) DEFAULT NULL,
  `duration_days` int(11) DEFAULT NULL COMMENT 'Estimation durée rupture',
  `impact` enum('faible','moyen','eleve') DEFAULT 'moyen',
  `reported_to_supplier` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Ruptures signalées par BA ou Merchandiser';

-- --------------------------------------------------------

--
-- Structure de la table `visit_stocks`
--

DROP TABLE IF EXISTS `visit_stocks`;
CREATE TABLE `visit_stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `visit_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(10) UNSIGNED NOT NULL,
  `stock_initial` int(11) NOT NULL COMMENT 'Stock début visite',
  `stock_final` int(11) NOT NULL COMMENT 'Stock fin visite',
  `unit` enum('packs','bouteilles','unites') DEFAULT 'packs',
  `sales_quantity` int(11) GENERATED ALWAYS AS (`stock_initial` - `stock_final`) STORED,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_open_violations`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_open_violations`;
CREATE TABLE `v_open_violations` (
`id` bigint(20) unsigned
,`visit_date` date
,`pdv_name` varchar(200)
,`reporter` varchar(201)
,`violation_type` enum('produit_concurrent','materiel_endommage','non_respect_merchandising','hygiene','autre')
,`severity` enum('faible','moyenne','grave','critique')
,`description` text
,`days_open` int(7)
,`status` enum('ouverte','en_cours','resolue','fermee')
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_pdv_average_sovi`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_pdv_average_sovi`;
CREATE TABLE `v_pdv_average_sovi` (
`pdv_id` bigint(20) unsigned
,`pdv_name` varchar(200)
,`city` varchar(100)
,`sector` varchar(100)
,`avg_sovi_sabc` decimal(9,6)
,`avg_sovi_sp` decimal(9,6)
,`avg_sovi_ucb` decimal(9,6)
,`avg_sovi_total` decimal(11,6)
,`total_visits` bigint(21)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_sector_weekly_performance`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_sector_weekly_performance`;
CREATE TABLE `v_sector_weekly_performance` (
`sector` varchar(100)
,`year_week` int(6)
,`pdv_visited` bigint(21)
,`total_visits` bigint(21)
,`avg_sovi_sabc` decimal(9,6)
,`violations_detected` bigint(21)
,`validated_visits` decimal(22,0)
);

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `v_user_visit_summary`
-- (Voir ci-dessous la vue réelle)
--
DROP VIEW IF EXISTS `v_user_visit_summary`;
CREATE TABLE `v_user_visit_summary` (
`user_id` bigint(20) unsigned
,`full_name` varchar(201)
,`role` varchar(100)
,`sector` varchar(100)
,`total_visits` bigint(21)
,`validated_visits` decimal(22,0)
,`rejected_visits` decimal(22,0)
,`draft_visits` decimal(22,0)
,`avg_visit_duration_minutes` decimal(24,4)
);

-- --------------------------------------------------------

--
-- Structure de la vue `v_open_violations`
--
DROP TABLE IF EXISTS `v_open_violations`;

DROP VIEW IF EXISTS `v_open_violations`;
CREATE OR REPLACE VIEW `v_open_violations`  AS SELECT `vio`.`id` AS `id`, `vi`.`visit_date` AS `visit_date`, `p`.`name` AS `pdv_name`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `reporter`, `vio`.`violation_type` AS `violation_type`, `vio`.`severity` AS `severity`, `vio`.`description` AS `description`, to_days(curdate()) - to_days(`vi`.`visit_date`) AS `days_open`, `vio`.`status` AS `status` FROM (((`violations` `vio` join `visits` `vi` on(`vio`.`visit_id` = `vi`.`id`)) join `pdv` `p` on(`vi`.`pdv_id` = `p`.`id`)) join `users` `u` on(`vi`.`user_id` = `u`.`id`)) WHERE `vio`.`status` in ('ouverte','en_cours') ORDER BY `vio`.`severity` DESC, to_days(curdate()) - to_days(`vi`.`visit_date`) DESC ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_pdv_average_sovi`
--
DROP TABLE IF EXISTS `v_pdv_average_sovi`;

DROP VIEW IF EXISTS `v_pdv_average_sovi`;
CREATE OR REPLACE VIEW `v_pdv_average_sovi`  AS SELECT `p`.`id` AS `pdv_id`, `p`.`name` AS `pdv_name`, `p`.`city` AS `city`, `s`.`name` AS `sector`, avg(`vs`.`sovi_sabc`) AS `avg_sovi_sabc`, avg(`vs`.`sovi_sp`) AS `avg_sovi_sp`, avg(`vs`.`sovi_ucb_autres`) AS `avg_sovi_ucb`, avg(`vs`.`sovi_sabc`) + avg(`vs`.`sovi_sp`) + avg(`vs`.`sovi_ucb_autres`) AS `avg_sovi_total`, count(distinct `v`.`id`) AS `total_visits` FROM (((`pdv` `p` join `sectors` `s` on(`p`.`sector_id` = `s`.`id`)) left join `visits` `v` on(`p`.`id` = `v`.`pdv_id` and `v`.`status` = 'validated')) left join `visit_sovi` `vs` on(`v`.`id` = `vs`.`visit_id`)) GROUP BY `p`.`id`, `p`.`name`, `p`.`city`, `s`.`name` ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_sector_weekly_performance`
--
DROP TABLE IF EXISTS `v_sector_weekly_performance`;

DROP VIEW IF EXISTS `v_sector_weekly_performance`;
CREATE OR REPLACE VIEW `v_sector_weekly_performance`  AS SELECT `s`.`name` AS `sector`, yearweek(`v`.`visit_date`,0) AS `year_week`, count(distinct `v`.`pdv_id`) AS `pdv_visited`, count(`v`.`id`) AS `total_visits`, avg(`vs_sovi`.`sovi_sabc`) AS `avg_sovi_sabc`, count(distinct `vio`.`id`) AS `violations_detected`, sum(case when `v`.`status` = 'validated' then 1 else 0 end) AS `validated_visits` FROM ((((`sectors` `s` join `pdv` `p` on(`s`.`id` = `p`.`sector_id`)) left join `visits` `v` on(`p`.`id` = `v`.`pdv_id`)) left join `visit_sovi` `vs_sovi` on(`v`.`id` = `vs_sovi`.`visit_id`)) left join `violations` `vio` on(`v`.`id` = `vio`.`visit_id`)) GROUP BY `s`.`name`, yearweek(`v`.`visit_date`,0) ;

-- --------------------------------------------------------

--
-- Structure de la vue `v_user_visit_summary`
--
DROP TABLE IF EXISTS `v_user_visit_summary`;

DROP VIEW IF EXISTS `v_user_visit_summary`;
CREATE OR REPLACE VIEW `v_user_visit_summary`  AS SELECT `u`.`id` AS `user_id`, concat(`u`.`first_name`,' ',`u`.`last_name`) AS `full_name`, `r`.`name` AS `role`, `s`.`name` AS `sector`, count(`v`.`id`) AS `total_visits`, sum(case when `v`.`status` = 'validated' then 1 else 0 end) AS `validated_visits`, sum(case when `v`.`status` = 'rejected' then 1 else 0 end) AS `rejected_visits`, sum(case when `v`.`status` = 'draft' then 1 else 0 end) AS `draft_visits`, avg(timestampdiff(MINUTE,`v`.`arrival_time`,`v`.`departure_time`)) AS `avg_visit_duration_minutes` FROM (((`users` `u` left join `roles` `r` on(`u`.`role_id` = `r`.`id`)) left join `sectors` `s` on(`u`.`sector_id` = `s`.`id`)) left join `visits` `v` on(`u`.`id` = `v`.`user_id`)) GROUP BY `u`.`id`, concat(`u`.`first_name`,' ',`u`.`last_name`), `r`.`name`, `s`.`name` ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_entity` (`entity_type`,`entity_id`),
  ADD KEY `idx_user_action` (`user_id`,`action`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Index pour la table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_company` (`company`),
  ADD KEY `idx_competitor` (`is_competitor`);

--
-- Index pour la table `competitor_activities`
--
ALTER TABLE `competitor_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `competitor_brand_id` (`competitor_brand_id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_type` (`activity_type`);

--
-- Index pour la table `districts`
--
ALTER TABLE `districts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `idx_region` (`region_id`);

--
-- Index pour la table `equipment_types`
--
ALTER TABLE `equipment_types`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_unread` (`user_id`,`is_read`),
  ADD KEY `idx_type` (`notification_type`);

--
-- Index pour la table `objectives`
--
ALTER TABLE `objectives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_period` (`period_start`,`period_end`);

--
-- Index pour la table `pdv`
--
ALTER TABLE `pdv`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `idx_sector` (`sector_id`),
  ADD KEY `idx_type_status` (`type`,`status`),
  ADD KEY `idx_city` (`city`);

--
-- Index pour la table `pdv_assignments`
--
ALTER TABLE `pdv_assignments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_active_assignment` (`user_id`,`pdv_id`,`is_active`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_pdv` (`pdv_id`),
  ADD KEY `idx_active` (`is_active`);

--
-- Index pour la table `pdv_equipment`
--
ALTER TABLE `pdv_equipment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_pdv` (`pdv_id`),
  ADD KEY `idx_type` (`equipment_type_id`),
  ADD KEY `idx_status` (`status`);

--
-- Index pour la table `performance_metrics`
--
ALTER TABLE `performance_metrics`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_date` (`user_id`,`metric_date`),
  ADD KEY `idx_date` (`metric_date`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sku` (`sku`),
  ADD KEY `idx_category` (`category_id`),
  ADD KEY `idx_brand` (`brand_id`),
  ADD KEY `idx_type` (`type`),
  ADD KEY `idx_status` (`status`);

--
-- Index pour la table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `parent_id` (`parent_id`);

--
-- Index pour la table `promotions`
--
ALTER TABLE `promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_dates` (`start_date`,`end_date`),
  ADD KEY `idx_status` (`status`);

--
-- Index pour la table `regions`
--
ALTER TABLE `regions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Index pour la table `sectors`
--
ALTER TABLE `sectors`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `idx_district` (`district_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `region_id` (`region_id`),
  ADD KEY `district_id` (`district_id`),
  ADD KEY `idx_role` (`role_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_sector` (`sector_id`);

--
-- Index pour la table `violations`
--
ALTER TABLE `violations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipment_id` (`equipment_id`),
  ADD KEY `reported_to` (`reported_to`),
  ADD KEY `resolved_by` (`resolved_by`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_severity` (`severity`),
  ADD KEY `idx_type` (`violation_type`);

--
-- Index pour la table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `validated_by` (`validated_by`),
  ADD KEY `idx_user_date` (`user_id`,`visit_date`),
  ADD KEY `idx_pdv_date` (`pdv_id`,`visit_date`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_date_status` (`visit_date`,`status`);

--
-- Index pour la table `visit_activations`
--
ALTER TABLE `visit_activations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `visit_id` (`visit_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Index pour la table `visit_ba_materials`
--
ALTER TABLE `visit_ba_materials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_type` (`material_type`);

--
-- Index pour la table `visit_ba_objectives`
--
ALTER TABLE `visit_ba_objectives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`);

--
-- Index pour la table `visit_ba_objectives_details`
--
ALTER TABLE `visit_ba_objectives_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `visit_objectives_id` (`visit_objectives_id`);

--
-- Index pour la table `visit_equipment_inspections`
--
ALTER TABLE `visit_equipment_inspections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_equipment` (`equipment_id`),
  ADD KEY `idx_violation` (`violation_detected`);

--
-- Index pour la table `visit_expiry_dates`
--
ALTER TABLE `visit_expiry_dates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_expiry_date` (`expiry_date`);

--
-- Index pour la table `visit_highlights`
--
ALTER TABLE `visit_highlights`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_priority` (`priority`);

--
-- Index pour la table `visit_merchandising`
--
ALTER TABLE `visit_merchandising`
  ADD PRIMARY KEY (`id`),
  ADD KEY `visit_id` (`visit_id`);

--
-- Index pour la table `visit_photos`
--
ALTER TABLE `visit_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_type` (`photo_type`);

--
-- Index pour la table `visit_promotions`
--
ALTER TABLE `visit_promotions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `promotion_id` (`promotion_id`),
  ADD KEY `idx_visit` (`visit_id`);

--
-- Index pour la table `visit_sovi`
--
ALTER TABLE `visit_sovi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_category` (`category`);

--
-- Index pour la table `visit_stockouts`
--
ALTER TABLE `visit_stockouts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_product` (`product_id`),
  ADD KEY `idx_impact` (`impact`);

--
-- Index pour la table `visit_stocks`
--
ALTER TABLE `visit_stocks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_product` (`product_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `competitor_activities`
--
ALTER TABLE `competitor_activities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `districts`
--
ALTER TABLE `districts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `equipment_types`
--
ALTER TABLE `equipment_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT pour la table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `objectives`
--
ALTER TABLE `objectives`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pdv`
--
ALTER TABLE `pdv`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `pdv_assignments`
--
ALTER TABLE `pdv_assignments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pdv_equipment`
--
ALTER TABLE `pdv_equipment`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `performance_metrics`
--
ALTER TABLE `performance_metrics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `promotions`
--
ALTER TABLE `promotions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `regions`
--
ALTER TABLE `regions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `sectors`
--
ALTER TABLE `sectors`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT pour la table `violations`
--
ALTER TABLE `violations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visits`
--
ALTER TABLE `visits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_activations`
--
ALTER TABLE `visit_activations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_ba_materials`
--
ALTER TABLE `visit_ba_materials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_ba_objectives`
--
ALTER TABLE `visit_ba_objectives`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_ba_objectives_details`
--
ALTER TABLE `visit_ba_objectives_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_equipment_inspections`
--
ALTER TABLE `visit_equipment_inspections`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_expiry_dates`
--
ALTER TABLE `visit_expiry_dates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_highlights`
--
ALTER TABLE `visit_highlights`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_merchandising`
--
ALTER TABLE `visit_merchandising`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_photos`
--
ALTER TABLE `visit_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_promotions`
--
ALTER TABLE `visit_promotions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_sovi`
--
ALTER TABLE `visit_sovi`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_stockouts`
--
ALTER TABLE `visit_stockouts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `visit_stocks`
--
ALTER TABLE `visit_stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `competitor_activities`
--
ALTER TABLE `competitor_activities`
  ADD CONSTRAINT `competitor_activities_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `competitor_activities_ibfk_2` FOREIGN KEY (`competitor_brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `districts`
--
ALTER TABLE `districts`
  ADD CONSTRAINT `districts_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `objectives`
--
ALTER TABLE `objectives`
  ADD CONSTRAINT `objectives_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `pdv`
--
ALTER TABLE `pdv`
  ADD CONSTRAINT `pdv_ibfk_1` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `pdv_assignments`
--
ALTER TABLE `pdv_assignments`
  ADD CONSTRAINT `pdv_assignments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pdv_assignments_ibfk_2` FOREIGN KEY (`pdv_id`) REFERENCES `pdv` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `pdv_equipment`
--
ALTER TABLE `pdv_equipment`
  ADD CONSTRAINT `pdv_equipment_ibfk_1` FOREIGN KEY (`pdv_id`) REFERENCES `pdv` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pdv_equipment_ibfk_2` FOREIGN KEY (`equipment_type_id`) REFERENCES `equipment_types` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `performance_metrics`
--
ALTER TABLE `performance_metrics`
  ADD CONSTRAINT `performance_metrics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `product_categories`
--
ALTER TABLE `product_categories`
  ADD CONSTRAINT `product_categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `promotions`
--
ALTER TABLE `promotions`
  ADD CONSTRAINT `promotions_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `sectors`
--
ALTER TABLE `sectors`
  ADD CONSTRAINT `sectors_ibfk_1` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON UPDATE CASCADE;

--
-- Contraintes pour la table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_2` FOREIGN KEY (`region_id`) REFERENCES `regions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_3` FOREIGN KEY (`district_id`) REFERENCES `districts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_ibfk_4` FOREIGN KEY (`sector_id`) REFERENCES `sectors` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `violations`
--
ALTER TABLE `violations`
  ADD CONSTRAINT `violations_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `violations_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `pdv_equipment` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `violations_ibfk_3` FOREIGN KEY (`reported_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `violations_ibfk_4` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `visits`
--
ALTER TABLE `visits`
  ADD CONSTRAINT `visits_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visits_ibfk_2` FOREIGN KEY (`pdv_id`) REFERENCES `pdv` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visits_ibfk_3` FOREIGN KEY (`validated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_activations`
--
ALTER TABLE `visit_activations`
  ADD CONSTRAINT `visit_activations_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_activations_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_ba_materials`
--
ALTER TABLE `visit_ba_materials`
  ADD CONSTRAINT `visit_ba_materials_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_ba_materials_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_ba_objectives`
--
ALTER TABLE `visit_ba_objectives`
  ADD CONSTRAINT `visit_ba_objectives_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_ba_objectives_details`
--
ALTER TABLE `visit_ba_objectives_details`
  ADD CONSTRAINT `visit_ba_objectives_details_ibfk_1` FOREIGN KEY (`visit_objectives_id`) REFERENCES `visit_ba_objectives` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_equipment_inspections`
--
ALTER TABLE `visit_equipment_inspections`
  ADD CONSTRAINT `visit_equipment_inspections_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_equipment_inspections_ibfk_2` FOREIGN KEY (`equipment_id`) REFERENCES `pdv_equipment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_expiry_dates`
--
ALTER TABLE `visit_expiry_dates`
  ADD CONSTRAINT `visit_expiry_dates_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_expiry_dates_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_highlights`
--
ALTER TABLE `visit_highlights`
  ADD CONSTRAINT `visit_highlights_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_merchandising`
--
ALTER TABLE `visit_merchandising`
  ADD CONSTRAINT `visit_merchandising_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_photos`
--
ALTER TABLE `visit_photos`
  ADD CONSTRAINT `visit_photos_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_promotions`
--
ALTER TABLE `visit_promotions`
  ADD CONSTRAINT `visit_promotions_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_promotions_ibfk_2` FOREIGN KEY (`promotion_id`) REFERENCES `promotions` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_sovi`
--
ALTER TABLE `visit_sovi`
  ADD CONSTRAINT `visit_sovi_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_stockouts`
--
ALTER TABLE `visit_stockouts`
  ADD CONSTRAINT `visit_stockouts_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_stockouts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Contraintes pour la table `visit_stocks`
--
ALTER TABLE `visit_stocks`
  ADD CONSTRAINT `visit_stocks_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `visit_stocks_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
