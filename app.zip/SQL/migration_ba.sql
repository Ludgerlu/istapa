-- =====================================================
-- SCRIPT DE MIGRATION - Support Brand Ambassador
-- Base de données : mtrade
-- Date : 16 janvier 2026
-- Version : 1.1
-- =====================================================
-- Ce script ajoute le support complet pour les Brand Ambassadors
-- sans recréer toute la base de données
-- =====================================================

USE `mtrade`;

-- =====================================================
-- 1. CRÉATION TABLE OBJECTIFS & RÉALISATIONS BA
-- =====================================================

CREATE TABLE IF NOT EXISTS `visit_ba_objectives` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `visit_id` BIGINT UNSIGNED NOT NULL,
    `objective_sales_influenced` INT COMMENT 'Objectif de ventes influencées',
    `actual_sales_influenced` INT COMMENT 'Réalisations: ventes influencées',
    `objective_products_promoted` INT COMMENT 'Nombre de produits à promouvoir',
    `actual_products_promoted` INT COMMENT 'Nombre de produits promus',
    `clients_engaged` INT COMMENT 'Nombre de clients conseillés',
    `achievement_rate` DECIMAL(5, 2) COMMENT 'Taux de réalisation en %',
    `notes` TEXT COMMENT 'Faits saillants de la journée',
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`visit_id`) REFERENCES `visits`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX `idx_visit` (`visit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci 
COMMENT='Objectifs et réalisations quotidiennes des Brand Ambassadors';

-- =====================================================
-- 2. CRÉATION TABLE MATÉRIEL PROMOTIONNEL BA
-- =====================================================

CREATE TABLE IF NOT EXISTS `visit_ba_materials` (
    `id` BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
    `visit_id` BIGINT UNSIGNED NOT NULL,
    `material_type` ENUM('echantillon', 'goodie', 'plv', 'brochure', 'autre') NOT NULL,
    `product_id` INT UNSIGNED COMMENT 'Produit concerné si applicable',
    `description` VARCHAR(200),
    `quantity_distributed` INT COMMENT 'Quantité distribuée',
    `photo_path` VARCHAR(500),
    `notes` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (`visit_id`) REFERENCES `visits`(`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX `idx_visit` (`visit_id`),
    INDEX `idx_type` (`material_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci 
COMMENT='Matériel promotionnel utilisé par les Brand Ambassadors';

-- =====================================================
-- 3. MISE À JOUR DES COMMENTAIRES DES TABLES EXISTANTES
-- =====================================================

-- Clarifier que les ruptures de stock sont pour BA et Merchandiser
ALTER TABLE `visit_stockouts` 
COMMENT='Ruptures signalées par BA ou Merchandiser';

-- Clarifier que les dates de péremption sont pour BA et Merchandiser
ALTER TABLE `visit_expiry_dates` 
COMMENT='Dates de péremption signalées par BA ou Merchandiser. Note: days_until_expiry calculé dynamiquement via DATEDIFF(expiry_date, CURDATE()) dans les requêtes';

-- Clarifier que le suivi des promotions est pour BA et Merchandiser
ALTER TABLE `visit_promotions` 
COMMENT='Suivi des promotions par BA et Merchandiser';

-- Clarifier que les activations sont principalement pour BA
ALTER TABLE `visit_activations` 
COMMENT='Activations promotionnelles réalisées par les Brand Ambassadors';

-- =====================================================
-- 4. VÉRIFICATION DES MODIFICATIONS
-- =====================================================

-- Afficher un message de confirmation
SELECT 'Migration réussie : Support Brand Ambassador ajouté' AS status;

-- Compter les nouvelles tables créées
SELECT 
    COUNT(*) as nouvelles_tables_creees
FROM information_schema.TABLES 
WHERE TABLE_SCHEMA = 'mtrade' 
AND TABLE_NAME IN ('visit_ba_objectives', 'visit_ba_materials');

-- =====================================================
-- 5. NOTES DE MIGRATION
-- =====================================================
/*
TABLES AJOUTÉES :
- visit_ba_objectives : Objectifs et réalisations quotidiennes des BA
- visit_ba_materials : Matériel promotionnel utilisé par les BA

TABLES MODIFIÉES (commentaires uniquement) :
- visit_stockouts : Ajout précision "BA ou Merchandiser"
- visit_expiry_dates : Ajout précision "BA ou Merchandiser"
- visit_promotions : Ajout précision "BA et Merchandiser"
- visit_activations : Ajout précision "principalement BA"

AUCUNE DONNÉE EXISTANTE N'EST AFFECTÉE
AUCUNE STRUCTURE DE TABLE EXISTANTE N'EST MODIFIÉE
*/

-- =====================================================
-- FIN DU SCRIPT DE MIGRATION
-- =====================================================